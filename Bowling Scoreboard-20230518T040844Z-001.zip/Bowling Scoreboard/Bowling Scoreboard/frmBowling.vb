﻿'Name:    Christopher Inthavong
'Date:    10/26/17
'Program: Bowling Scoreboard
'Purpose: This application collects and keeps track of each frame's
'         score in a bowling match for one person.

Option Strict On

Public Class frmBowling
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Declares Variables
        Dim intScore As Decimal
        Dim strScore As String
        Dim intTotalScore As Decimal = 0D
        Dim intFinalScore As Decimal
        Dim strNormMsg As String = "Enter a score for frame # "
        Dim strHeading As String = "Score"
        Dim strBody As String = "Enter a score for frame # "
        Dim strNotNumeric As String = "Enter a numeric score for frame # "
        Dim strNegative As String = "Enter a positive score for frame # "
        Dim decNumberofEntries As Decimal = 1
        Dim decMaxEntries As Decimal = 10
        Dim strCancel As String = ""
        'Creates input box when button is clicked
        strScore = InputBox(strBody & decNumberofEntries, strHeading, " ")
        Do Until decNumberofEntries > decMaxEntries Or strScore = strCancel
            'Checks if score is a numeric value
            If IsNumeric(strScore) Then
                intScore = Convert.ToDecimal(strScore)
                'Checks if score is positive
                If intScore >= 0 And intScore <= 30 Then
                    intTotalScore += intScore
                    decNumberofEntries += 1
                    strBody = strNormMsg
                    lstScores.Items.Add("Frame Score " & intScore & " TotalScore " & intTotalScore)
                Else
                    strBody = strNotNumeric
                End If
            Else
                strBody = strNotNumeric
            End If
            'Continues looping and displaying inputbox until reaching max entries
            'or if canceled.
            If decNumberofEntries <= decMaxEntries Then
                strScore = InputBox(strBody & decNumberofEntries, strHeading, " ")
            End If
        Loop
        'Calculates and diplays average
        If decNumberofEntries > 1 Then
            lblFinal.Visible = True
            intFinalScore = intTotalScore
            lblFinal.Text = "Final game score is " &
                intFinalScore.ToString("") & " points"
        Else
            MsgBox("No Value entered")
        End If
        'Disables Calculate Button
        btnCalculate.Enabled = False

    End Sub

    Private Sub mnuClear_Click(sender As Object, e As EventArgs) Handles mnuClear.Click

        'Clears lstScores item text and it also 
        'clears Label object lblFinal.

        lstScores.Items.Clear()
        lblFinal.Text = ""
        btnCalculate.Enabled = True

    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click

        'Closes the application.

        Me.Close()

    End Sub
End Class
