﻿' Program: City Bike Rental
' Author:  Christopher Inthavong
' Date:    9/7/17
' Purpose: This application calculates and
'          displays total cost of renting mutiple 
'          bikes for a 24 - hour period.
Option Strict On
Public Class frmBikeRental
    'This number is used multiple times for other parts of code
    Const _cdecPricePerBike As Decimal = 9.95D
    Private Sub frmBikeRental_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'This part of code displays the cost heading
        'clears text of Total Cost Label, and sets
        'focus on txtNumberOfBikes Textbox object.
        lblCostHeading.Text = _cdecPricePerBike.ToString("C") & " Per Bike for 24 Hours"
        lblTotalCost.Text = ""
        txtNumberOfBikes.Focus()
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'This part of code is activated when the user
        'taps or clicks the Calculate button. It calculates and
        'displays the cost of the bikes rented (Number of bikes rented x cost per bike).
        Dim strNumberOfBikes As String
        Dim intNumberOfBikes As Integer
        Dim decTotalCost As Decimal
        strNumberOfBikes = txtNumberOfBikes.Text
        intNumberOfBikes = Convert.ToInt32(strNumberOfBikes)
        decTotalCost = intNumberOfBikes * _cdecPricePerBike
        lblTotalCost.Text = decTotalCost.ToString("C")
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clicking the Clear button
        'clears number of bikes text box
        'and text of total cost label. It also puts focus on txtNumberOfBikes Textbox
        txtNumberOfBikes.Clear()
        lblTotalCost.Text = ""
        txtNumberOfBikes.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'This closes the window and ends the application
        Close()
    End Sub
End Class
