﻿'Name: Website Traffic Metric
'Author: Christopher Inthavong
'Date: 10/20/17
'Purpose: This program calculates the average traffic
'         amount for a website. IT uses loops.
'         btw there's a ghost button on my form
'         that I can't remove or find. 

Option Strict On
Public Class frmWebsiteTrafficMetric
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim strTrafficAmount As String
        Dim decTrafficAmount As Decimal
        Dim decAverageTime As Decimal
        Dim decTotalTrafficAmount As Decimal = 0D
        Dim strNonnumericError As String = "Enter a real value "
        Dim strNormalMessage As String = "Enter the time spent #"
        Dim strInputHeading As String = "Traffic Amount"
        Dim strInputMessage As String = "Enter the time spent #"
        Dim strNegativeError As String = "Error Enter a positive value for time spent."
        Dim intNumberOfEntries As Integer = 1
        Dim intMaxNumberOfEntries As Integer = 12
        Dim strCancelClicked As String = ""

        strTrafficAmount = InputBox(strInputMessage & intNumberOfEntries, strInputHeading, " ")
        Do Until intNumberOfEntries > intMaxNumberOfEntries Or strTrafficAmount = strCancelClicked
            If IsNumeric(strTrafficAmount) Then
                decTrafficAmount = Convert.ToDecimal(strTrafficAmount)
                If decTrafficAmount > 0 Then

                    decTotalTrafficAmount += decTrafficAmount
                    intNumberOfEntries += 1
                    strInputMessage = strNormalMessage
                    lstTime.Items.Add(decTrafficAmount)
                Else
                    strInputMessage = strNonnumericError
                End If
            Else
                strInputMessage = strNonnumericError
            End If
            If intNumberOfEntries <= intMaxNumberOfEntries Then
                strTrafficAmount = InputBox(strInputMessage & intNumberOfEntries, strInputHeading, " ")
            End If
        Loop
        'Calculates and diplays average
        If intNumberOfEntries > 1 Then
            lblAverage.Visible = True
            decAverageTime = decTotalTrafficAmount / (intNumberOfEntries - 1)
            lblAverage.Text = "Average time spent on the website is " &
                decAverageTime.ToString("F1") & " seconds"
        Else
            MsgBox("No weight loss value entered")
        End If
        'Disables weight loss button
        btnCalculate.Enabled = False
    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        Me.Close()
    End Sub

    Private Sub mnuClear_Click(sender As Object, e As EventArgs) Handles mnuClear.Click
        lstTime.Items.Clear()
        lblAverage.Text = ""
        btnCalculate.Enabled = True
    End Sub
End Class
