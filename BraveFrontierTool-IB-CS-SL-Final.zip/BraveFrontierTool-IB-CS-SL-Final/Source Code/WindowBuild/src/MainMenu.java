import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class MainMenu {      //class

	private JFrame frame;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenu window = new MainMenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainMenu(){
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize()  {
		frame = new JFrame("Brave Frontier Veteran Tool");
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(MainMenu.class.getResource("/com/sun/java/swing/plaf/windows/icons/HomeFolder.gif")));
		frame.setBounds(100, 100, 456, 397);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblBraveFrontierVeteran = new JLabel("Brave Frontier Veteran Tool");
		lblBraveFrontierVeteran.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblBraveFrontierVeteran.setBounds(71, 25, 310, 34);
		frame.getContentPane().add(lblBraveFrontierVeteran);
		
		JButton btnNewUnit = new JButton("Enter Unit Info");
		btnNewUnit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {  //This only happens when the button is clicked
				//Click button to move to another window.
				frame.dispose(); 					   //When the user clicks the Enter Unit Info button,
				NewUnit newUnitWindow = new NewUnit();//the application will close the current frame
				newUnitWindow.setVisible(true);      //and open up the corresponding frame.
			}
		});
		btnNewUnit.setBounds(148, 105, 144, 34); //Creates the size for btnNewUnit
		frame.getContentPane().add(btnNewUnit); 
		
		JButton btnSearch = new JButton("Search Unit Info");
		btnSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();							   //When the user clicks the Search Unit Info button,
				SearchUnit newSearchWindow = new SearchUnit();//the application will close the current frame
				newSearchWindow.setVisible(true);			 //and open up the corresponding frame.
			}
		});
		btnSearch.setBounds(148, 200, 144, 34);
		frame.getContentPane().add(btnSearch);
		
		JButton btnModifyUnitInfo = new JButton("Modify Unit Info");  
		btnModifyUnitInfo.addMouseListener(new MouseAdapter() {      
			@Override                                               
			public void mouseClicked(MouseEvent e) {
				frame.dispose();							   //When the user clicks the Modify Unit Info button,
				ModifyUnit newModifyWindow = new ModifyUnit();//the application will close the current frame
				newModifyWindow.setVisible(true);			 //and open up the corresponding frame.
			}
		});
		btnModifyUnitInfo.setBounds(148, 295, 144, 34);
		frame.getContentPane().add(btnModifyUnitInfo);
		
		JLabel lblClickOnA = new JLabel("Click on a button to get started.");
		lblClickOnA.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblClickOnA.setBounds(125, 70, 203, 14);
		frame.getContentPane().add(lblClickOnA);
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
