import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.awt.event.MouseEvent;

public class ModifyUnit extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtName;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModifyUnit frame = new ModifyUnit();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ModifyUnit() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 668, 319);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblInstructions = new JLabel("If you think you accidently put in the wrong info for a unit,");
		lblInstructions.setBounds(53, 50, 347, 14);
		contentPane.add(lblInstructions);
		
		JLabel lblInstruction2 = new JLabel("or need to update a unit's info, then you can find out here.");
		lblInstruction2.setBounds(53, 63, 347, 14);
		contentPane.add(lblInstruction2);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setBounds(20, 88, 54, 14);
		contentPane.add(lblName);
		
		txtName = new JTextField();
		txtName.setBounds(74, 85, 258, 20);
		contentPane.add(txtName);
		txtName.setColumns(10);
		
		JLabel lblNameHelp = new JLabel("Enter the name EXACTLY as you entered it, or the unit won't be found.");
		lblNameHelp.setBounds(20, 116, 414, 14);
		contentPane.add(lblNameHelp);
		
		JLabel lblTitle = new JLabel("Modify Unit Info");
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblTitle.setBounds(140, 11, 147, 28);
		contentPane.add(lblTitle);
		
		JLabel lblUnitName = new JLabel("Name:");
		lblUnitName.setBounds(20, 182, 514, 14);
		contentPane.add(lblUnitName);
		lblUnitName.setVisible(false);
		
		JButton btnEnter = new JButton("Enter");
		btnEnter.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				String name = txtName.getText();
				
				
				/////////////////////////////// Reads file to retrieve file contents and store into an array to be processed.

				 Scanner sf = null;
				try {
					sf = new Scanner(new File("output.txt"));
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("File not found.");
				}
				 
				    int maxCount = -1;
				   	String unitName[] = new String[500];
				   
				      while(sf.hasNext())
				    {
				      maxCount++;
				      unitName[maxCount] = sf.nextLine();
				    }
				    sf.close();
				 ////////////////////////////// End of storing into array
				    
				   
				 for(int i = 0; i <= maxCount; i++) 
				 {
					 Scanner sfnew = new Scanner(unitName[i]);
					 String fileName = unitName[i]; 

					   if(fileName.contains(name)) { 
						   
						   lblUnitName.setVisible(true);
							
							btnEnter.setEnabled(false);
							lblUnitName.setText(fileName);
							sfnew.close();
							
					   } else {
						   System.out.println("Name not found try again by entering the name differently.");
					   }
					  
					   
				 }
			}
		});
		btnEnter.setBounds(345, 84, 89, 23);
		contentPane.add(btnEnter);
		
		
	}
}
