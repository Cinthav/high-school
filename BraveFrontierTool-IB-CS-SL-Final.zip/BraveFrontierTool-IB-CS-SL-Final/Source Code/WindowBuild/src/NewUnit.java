import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.io.*;

public class NewUnit extends JFrame {     //Class

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private static JTextField txtName;
	private static JTextField txtHp;
	private static JTextField txtAtk;
	private static JTextField txtDef;
	private static JTextField txtRec;
	FileWriter fw;
	PrintWriter output;
	private JTextField txtRole;

	/**
	 * Launch the application.
	 */

	
	/**
	 * Create the frame.
	 */
	public NewUnit() {    //Constructor made by Eclipse plug-in (WindowBuilder)
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);             
		setBounds(100, 100, 480, 395);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitle = new JLabel("New Unit Entry");
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTitle.setBounds(161, 11, 167, 23);
		contentPane.add(lblTitle);
		
		JLabel lblInstructions = new JLabel("Enter a new unit entry by entering the exact values for your unit in each text box.");
		lblInstructions.setBounds(10, 48, 458, 14);
		contentPane.add(lblInstructions);
		
		txtName = new JTextField();
		txtName.setBounds(151, 73, 173, 20);
		contentPane.add(txtName);
		txtName.setColumns(10);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setBounds(95, 76, 46, 14);
		contentPane.add(lblName);
		
		JLabel lblExample = new JLabel("(example: Ignis Halcyon Vargas)");
		lblExample.setBounds(96, 104, 228, 14);
		contentPane.add(lblExample);
		
		JLabel lblHp = new JLabel("HP:");
		lblHp.setBounds(131, 144, 46, 14);
		contentPane.add(lblHp);
		
		txtHp = new JTextField();
		txtHp.setBounds(173, 141, 86, 20);
		contentPane.add(txtHp);
		txtHp.setColumns(10);
		
		JLabel lblAtk = new JLabel("ATK:");
		lblAtk.setBounds(131, 169, 46, 14);
		contentPane.add(lblAtk);
		
		txtAtk = new JTextField();
		txtAtk.setBounds(173, 166, 86, 20);
		contentPane.add(txtAtk);
		txtAtk.setColumns(10);
		
		JLabel lblDef = new JLabel("DEF:");
		lblDef.setBounds(131, 194, 46, 14);
		contentPane.add(lblDef);
		
		JLabel lblRec = new JLabel("REC:");
		lblRec.setBounds(131, 219, 46, 14);
		contentPane.add(lblRec);
		
		txtDef = new JTextField();
		txtDef.setBounds(173, 191, 86, 20);
		contentPane.add(txtDef);
		txtDef.setColumns(10);

		
		txtRec = new JTextField();
		txtRec.setBounds(173, 216, 86, 20);
		contentPane.add(txtRec);
		txtRec.setColumns(10);

		
		
		JLabel label = new JLabel("");
		label.setBounds(338, 95, 46, 14);
		contentPane.add(label);
		
		JLabel lblRole = new JLabel("Role:");
		lblRole.setBounds(131, 247, 46, 14);
		contentPane.add(lblRole);
		
		JButton btnFinish = new JButton("Finish\r\n\r\n");
		btnFinish.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e)  { 
				
				//When the user clicks the button,
				//Everything is hidden or disabled in the window(JFrame).
				txtName.setVisible(false);  
				txtHp.setVisible(false);
				txtAtk.setVisible(false);
				txtDef.setVisible(false);
				txtRec.setVisible(false);
				lblName.setVisible(false);
				lblHp.setVisible(false);
				lblAtk.setVisible(false);
				lblDef.setVisible(false);
				lblRec.setVisible(false);
				btnFinish.setEnabled(false);
				lblTitle.setVisible(false);
				lblInstructions.setVisible(false);
				lblExample.setVisible(false);			
				lblRole.setVisible(false);
				txtRole.setVisible(false);
				String name = txtName.getText();
				
				try {
					FileWriter fw = new FileWriter("output.txt",true);
					PrintWriter output = new PrintWriter(fw);
					output.println();
					fw.write(lblName.getText() + name + " ");
					fw.write(lblHp.getText() + txtHp.getText() + " ");
					fw.write(lblAtk.getText() + txtAtk.getText() + " ");
					fw.write(lblDef.getText() + txtDef.getText() + " ");
					fw.write(lblRec.getText()+ txtRec.getText() + " ");
					fw.write(lblRole.getText()+ txtRole.getText());
					
					fw.close();
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
			
			
			}
		});
		btnFinish.setBounds(170, 308, 89, 23);
		contentPane.add(btnFinish);
		
		txtRole = new JTextField();
		txtRole.setBounds(173, 244, 86, 20);
		contentPane.add(txtRole);
		txtRole.setColumns(10);
		
		JLabel lblHint = new JLabel("(Describe what the unit does for you in ONE word.)");
		lblHint.setBounds(81, 263, 328, 14);
		contentPane.add(lblHint);
	}
	public static void main(String[] args) throws IOException { 

					NewUnit frame = new NewUnit();
					frame.setVisible(true);

	}
}
