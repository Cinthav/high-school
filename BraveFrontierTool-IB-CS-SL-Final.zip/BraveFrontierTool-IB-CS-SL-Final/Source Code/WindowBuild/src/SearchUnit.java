import java.util.*;
import java.io.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SearchUnit extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtName;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearchUnit frame = new SearchUnit();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SearchUnit() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 390);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitle = new JLabel("Unit Search\r\n");
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblTitle.setBounds(171, 11, 169, 22);
		contentPane.add(lblTitle);
		
		JLabel lblInstructions = new JLabel("Search up stored unit data to compare by entering the appropriate values.");
		lblInstructions.setBounds(31, 44, 449, 14);
		contentPane.add(lblInstructions);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setBounds(81, 69, 46, 14);
		contentPane.add(lblName);
		
		JLabel lblHelp = new JLabel("(Name is case sensitive. Enter EXACTLY how you saved it)");
		lblHelp.setBounds(71, 94, 384, 14);
		contentPane.add(lblHelp);
		
		txtName = new JTextField();
		txtName.setBounds(137, 66, 225, 20);
		contentPane.add(txtName);
		txtName.setColumns(10);
		
		JLabel lblResultName = new JLabel("Info Stored:");
		lblResultName.setBounds(10, 162, 68, 14);
		contentPane.add(lblResultName);
		lblResultName.setVisible(false);
		
		JLabel lblUnitName = new JLabel("New label");
		lblUnitName.setBounds(88, 162, 492, 14);
		contentPane.add(lblUnitName);
		lblUnitName.setVisible(false);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				String name = txtName.getText();
				
				
				/////////////////////////////// Reads file to retrieve file contents and store into an array to be processed.

				 Scanner sf = null;
				try {
					sf = new Scanner(new File("output.txt"));
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("File not found.");
				}
				 
				    int maxCount = -1;
				   	String unitName[] = new String[500];
				   
				      while(sf.hasNext())
				    {
				      maxCount++;
				      unitName[maxCount] = sf.nextLine();
				    }
				    sf.close();
				 ////////////////////////////// End of storing into array
				    
				   
				 for(int i = 0; i <= maxCount; i++) 
				 {
					 Scanner sfnew = new Scanner(unitName[i]);
					 String fileName = unitName[i]; 

					   if(fileName.contains(name)) { 
						   
						   lblUnitName.setVisible(true);
							lblResultName.setVisible(true);
							btnSearch.setEnabled(false);
							lblUnitName.setText(fileName);
							sfnew.close();
							
					   } 
					  
					   
				 }
				
				sf.close();
			}
			
		});
		btnSearch.setBounds(142, 119, 89, 23);
		contentPane.add(btnSearch);
		
		
	}

}
