﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMonthlyPayCalc
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMonthlyPayCalc))
        Me.picCoins = New System.Windows.Forms.PictureBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.radPenny = New System.Windows.Forms.RadioButton()
        Me.radNickel = New System.Windows.Forms.RadioButton()
        Me.txtDays = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuClear = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.lblDays = New System.Windows.Forms.Label()
        Me.lblInfo1 = New System.Windows.Forms.Label()
        Me.lblInfo2 = New System.Windows.Forms.Label()
        Me.lblMainInfo = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        CType(Me.picCoins, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'picCoins
        '
        Me.picCoins.Image = CType(resources.GetObject("picCoins.Image"), System.Drawing.Image)
        Me.picCoins.Location = New System.Drawing.Point(0, 261)
        Me.picCoins.Name = "picCoins"
        Me.picCoins.Size = New System.Drawing.Size(474, 199)
        Me.picCoins.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCoins.TabIndex = 0
        Me.picCoins.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(84, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(306, 25)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "Penny a Day or Nickel a Day"
        '
        'radPenny
        '
        Me.radPenny.AutoSize = True
        Me.radPenny.Location = New System.Drawing.Point(15, 121)
        Me.radPenny.Name = "radPenny"
        Me.radPenny.Size = New System.Drawing.Size(96, 17)
        Me.radPenny.TabIndex = 2
        Me.radPenny.TabStop = True
        Me.radPenny.Text = "New Employee"
        Me.radPenny.UseVisualStyleBackColor = True
        '
        'radNickel
        '
        Me.radNickel.AutoSize = True
        Me.radNickel.Location = New System.Drawing.Point(15, 167)
        Me.radNickel.Name = "radNickel"
        Me.radNickel.Size = New System.Drawing.Size(122, 17)
        Me.radNickel.TabIndex = 3
        Me.radNickel.TabStop = True
        Me.radNickel.Text = "Experienced Worker"
        Me.radNickel.UseVisualStyleBackColor = True
        '
        'txtDays
        '
        Me.txtDays.Location = New System.Drawing.Point(97, 227)
        Me.txtDays.Name = "txtDays"
        Me.txtDays.Size = New System.Drawing.Size(100, 20)
        Me.txtDays.TabIndex = 4
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(474, 24)
        Me.MenuStrip1.TabIndex = 5
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuClear, Me.mnuExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "File"
        '
        'mnuClear
        '
        Me.mnuClear.Name = "mnuClear"
        Me.mnuClear.Size = New System.Drawing.Size(101, 22)
        Me.mnuClear.Text = "&Clear"
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(101, 22)
        Me.mnuExit.Text = "E&xit"
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Location = New System.Drawing.Point(247, 150)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(67, 13)
        Me.lblResult.TabIndex = 6
        Me.lblResult.Text = "xxxxxxxxxxxx"
        Me.lblResult.Visible = False
        '
        'lblInfo
        '
        Me.lblInfo.AutoSize = True
        Me.lblInfo.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo.Location = New System.Drawing.Point(12, 83)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(140, 18)
        Me.lblInfo.TabIndex = 7
        Me.lblInfo.Text = "Work Experience:"
        '
        'lblDays
        '
        Me.lblDays.AutoSize = True
        Me.lblDays.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDays.Location = New System.Drawing.Point(8, 229)
        Me.lblDays.Name = "lblDays"
        Me.lblDays.Size = New System.Drawing.Size(83, 14)
        Me.lblDays.TabIndex = 8
        Me.lblDays.Text = "Days Worked:"
        '
        'lblInfo1
        '
        Me.lblInfo1.AutoSize = True
        Me.lblInfo1.Location = New System.Drawing.Point(12, 141)
        Me.lblInfo1.Name = "lblInfo1"
        Me.lblInfo1.Size = New System.Drawing.Size(160, 13)
        Me.lblInfo1.TabIndex = 9
        Me.lblInfo1.Text = "New employees start with $0.01 "
        '
        'lblInfo2
        '
        Me.lblInfo2.AutoSize = True
        Me.lblInfo2.Location = New System.Drawing.Point(12, 187)
        Me.lblInfo2.Name = "lblInfo2"
        Me.lblInfo2.Size = New System.Drawing.Size(222, 13)
        Me.lblInfo2.TabIndex = 10
        Me.lblInfo2.Text = "Experienced workers start with a pay of $0.05"
        '
        'lblMainInfo
        '
        Me.lblMainInfo.AutoSize = True
        Me.lblMainInfo.Location = New System.Drawing.Point(53, 34)
        Me.lblMainInfo.Name = "lblMainInfo"
        Me.lblMainInfo.Size = New System.Drawing.Size(379, 26)
        Me.lblMainInfo.TabIndex = 11
        Me.lblMainInfo.Text = "Choose your work experience to determine your starting pay. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "It will double each" &
    " subsequent workday. Finally, enter the workdays completed."
        Me.lblMainInfo.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(203, 225)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(111, 23)
        Me.btnCalculate.TabIndex = 12
        Me.btnCalculate.Text = "Calculate Final Pay"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'frmMonthlyPayCalc
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(474, 459)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblMainInfo)
        Me.Controls.Add(Me.lblInfo2)
        Me.Controls.Add(Me.lblInfo1)
        Me.Controls.Add(Me.lblDays)
        Me.Controls.Add(Me.lblInfo)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.txtDays)
        Me.Controls.Add(Me.radNickel)
        Me.Controls.Add(Me.radPenny)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.picCoins)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMonthlyPayCalc"
        Me.Text = "Penny A Day or Nickel a Day"
        CType(Me.picCoins, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picCoins As PictureBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents radPenny As RadioButton
    Friend WithEvents radNickel As RadioButton
    Friend WithEvents txtDays As TextBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents mnuFile As ToolStripMenuItem
    Friend WithEvents mnuClear As ToolStripMenuItem
    Friend WithEvents mnuExit As ToolStripMenuItem
    Friend WithEvents lblResult As Label
    Friend WithEvents lblInfo As Label
    Friend WithEvents lblDays As Label
    Friend WithEvents lblInfo1 As Label
    Friend WithEvents lblInfo2 As Label
    Friend WithEvents lblMainInfo As Label
    Friend WithEvents btnCalculate As Button
End Class
