﻿' Name: Penny a Day or Nickel a Day
' Date: 11/9/17
' Author: Christopher Inthavong
' Purpose: Calculates monthly pay.

Option Strict On
Public Class frmMonthlyPayCalc
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Assigns variables
        Dim intDaysNew, intDaysE As Integer
        Dim intCounter As Integer = 1
        Dim decTotal As Decimal
        Dim decNew As Decimal = 0.01D
        Dim decExperienced As Decimal = 0.05D
        'Error check first then it runs the loop for experienced.
        If IsNumeric(txtDays.Text) Then
            If radNickel.Checked Then
                intDaysE = Convert.ToInt32(txtDays.Text)
                If intDaysE >= 16 And intDaysE <= 22 Then
                    Do Until intCounter = intDaysE
                        decTotal += decExperienced
                        decExperienced *= 2
                        intCounter += 1
                    Loop
                    lblResult.Visible = True ' Displays result

                    lblResult.Text = "Your total pay is " & "$" & decTotal + decExperienced
                Else
                    MsgBox("You cannot work less than 16 days or more than 22 days.") 'Error message
                End If
            ElseIf radPenny.Checked Then 'Checks if Penny radio button is checked instead.
                intDaysNew = Convert.ToInt32(txtDays.Text)
                If intDaysNew >= 19 And intDaysNew <= 22 Then
                    Do Until intCounter = intDaysNew
                        decTotal += decNew
                        decNew *= 2
                        intCounter += 1
                    Loop
                    lblResult.Visible = True

                    lblResult.Text = "Your total pay is " & "$" & decTotal + decNew
                Else
                    MsgBox("You cannot work less than 19 days or more than 22 days.")
                End If
            End If
        Else
            MsgBox("Enter a numeric value for days worked.")
        End If
    End Sub

    Private Sub mnuClear_Click(sender As Object, e As EventArgs) Handles mnuClear.Click
        'Clears everything and resets them back to normal
        radPenny.Checked = True
        txtDays.Text = ""
        lblResult.Text = ""
        btnCalculate.Enabled = True
    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        'Closes the application
        Me.Close()
    End Sub
End Class
