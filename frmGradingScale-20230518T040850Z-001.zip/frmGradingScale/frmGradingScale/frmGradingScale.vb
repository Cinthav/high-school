﻿'Name:    Grading Scale Converter
'Date:    9/15/17
'Author:  Christopher Inthavong
'Purpose: This application takes the numeric input of 
'         the user and converts it to a letter grade.
Public Class frmGradingScale
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clears text box and result label.
        txtInput.Text = ""
        lblResult.Text = ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Do I even have to tell what this does?
        Me.Close()
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Does all the work. Converts numeric input into a letter grade.

        If txtInput.Text >= 90 And txtInput.Text <= 100 Then
            lblResult.Text = "You got an A"
        ElseIf txtInput.Text >= 87 And txtInput.Text <= 89 Then
            lblResult.Text = "You got a B+"
        ElseIf txtInput.Text >= 80 And txtInput.Text <= 86 Then
            lblResult.Text = "You got a B"
        ElseIf txtInput.Text >= 77 And txtInput.Text <= 79 Then
            lblResult.Text = "You got a C+"
        ElseIf txtInput.Text >= 70 And txtInput.Text <= 76 Then
            lblResult.Text = "You got a C"
        ElseIf txtInput.Text >= 67 And txtInput.Text <= 69 Then
            lblResult.Text = "You got a D+"
        ElseIf txtInput.Text >= 60 And txtInput.Text <= 66 Then
            lblResult.Text = "You got a D"
        ElseIf txtInput.Text >= 0 And txtInput.Text <= 59 Then
            lblResult.Text = "You got a F"
        End If

    End Sub

    Private Sub frmGradingScale_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Loads the form and preps everything
        lblResult.Text = ""
        txtInput.Focus()
    End Sub
End Class
