﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAirlineSnack
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.btnCC = New System.Windows.Forms.Button()
        Me.btnSelect = New System.Windows.Forms.Button()
        Me.btnCookies = New System.Windows.Forms.Button()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.lblConfirmation = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.picSPretzels = New System.Windows.Forms.PictureBox()
        Me.picSPeanuts = New System.Windows.Forms.PictureBox()
        Me.picCookies = New System.Windows.Forms.PictureBox()
        Me.picCC = New System.Windows.Forms.PictureBox()
        Me.btnSPeanuts = New System.Windows.Forms.Button()
        Me.btnSPretzels = New System.Windows.Forms.Button()
        CType(Me.picSPretzels, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSPeanuts, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCookies, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCC, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.lblHeading.Location = New System.Drawing.Point(149, 9)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(158, 25)
        Me.lblHeading.TabIndex = 0
        Me.lblHeading.Text = "Airline Snacks"
        '
        'btnCC
        '
        Me.btnCC.BackColor = System.Drawing.Color.Aquamarine
        Me.btnCC.Location = New System.Drawing.Point(69, 332)
        Me.btnCC.Name = "btnCC"
        Me.btnCC.Size = New System.Drawing.Size(124, 23)
        Me.btnCC.TabIndex = 3
        Me.btnCC.Text = "Cheese and Crackers"
        Me.btnCC.UseVisualStyleBackColor = False
        '
        'btnSelect
        '
        Me.btnSelect.BackColor = System.Drawing.Color.Aquamarine
        Me.btnSelect.Enabled = False
        Me.btnSelect.Location = New System.Drawing.Point(191, 459)
        Me.btnSelect.Name = "btnSelect"
        Me.btnSelect.Size = New System.Drawing.Size(75, 23)
        Me.btnSelect.TabIndex = 4
        Me.btnSelect.Text = "Select"
        Me.btnSelect.UseVisualStyleBackColor = False
        '
        'btnCookies
        '
        Me.btnCookies.BackColor = System.Drawing.Color.Aquamarine
        Me.btnCookies.Location = New System.Drawing.Point(263, 332)
        Me.btnCookies.Name = "btnCookies"
        Me.btnCookies.Size = New System.Drawing.Size(124, 23)
        Me.btnCookies.TabIndex = 5
        Me.btnCookies.Text = "Cookies"
        Me.btnCookies.UseVisualStyleBackColor = False
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstructions.Location = New System.Drawing.Point(91, 406)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(274, 14)
        Me.lblInstructions.TabIndex = 6
        Me.lblInstructions.Text = "Choose a snack and then click the Select Button"
        '
        'lblConfirmation
        '
        Me.lblConfirmation.AutoSize = True
        Me.lblConfirmation.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConfirmation.Location = New System.Drawing.Point(157, 431)
        Me.lblConfirmation.Name = "lblConfirmation"
        Me.lblConfirmation.Size = New System.Drawing.Size(145, 14)
        Me.lblConfirmation.TabIndex = 7
        Me.lblConfirmation.Text = "Your snack is on the way"
        Me.lblConfirmation.Visible = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Aquamarine
        Me.btnExit.Enabled = False
        Me.btnExit.Location = New System.Drawing.Point(191, 488)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'picSPretzels
        '
        Me.picSPretzels.Image = Global.Pizza_Selection.My.Resources.Resources.Salted_Pretzels
        Me.picSPretzels.Location = New System.Drawing.Point(244, 193)
        Me.picSPretzels.Name = "picSPretzels"
        Me.picSPretzels.Size = New System.Drawing.Size(158, 133)
        Me.picSPretzels.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSPretzels.TabIndex = 10
        Me.picSPretzels.TabStop = False
        Me.picSPretzels.Visible = False
        '
        'picSPeanuts
        '
        Me.picSPeanuts.Image = Global.Pizza_Selection.My.Resources.Resources.Salted_Peanuts
        Me.picSPeanuts.Location = New System.Drawing.Point(55, 193)
        Me.picSPeanuts.Name = "picSPeanuts"
        Me.picSPeanuts.Size = New System.Drawing.Size(158, 133)
        Me.picSPeanuts.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSPeanuts.TabIndex = 9
        Me.picSPeanuts.TabStop = False
        Me.picSPeanuts.Visible = False
        '
        'picCookies
        '
        Me.picCookies.Image = Global.Pizza_Selection.My.Resources.Resources.Chocolate_Chip_Cookies
        Me.picCookies.Location = New System.Drawing.Point(244, 54)
        Me.picCookies.Name = "picCookies"
        Me.picCookies.Size = New System.Drawing.Size(158, 133)
        Me.picCookies.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCookies.TabIndex = 2
        Me.picCookies.TabStop = False
        Me.picCookies.Visible = False
        '
        'picCC
        '
        Me.picCC.Image = Global.Pizza_Selection.My.Resources.Resources.Cheese___Crackers
        Me.picCC.Location = New System.Drawing.Point(55, 54)
        Me.picCC.Name = "picCC"
        Me.picCC.Size = New System.Drawing.Size(158, 133)
        Me.picCC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCC.TabIndex = 1
        Me.picCC.TabStop = False
        Me.picCC.Visible = False
        '
        'btnSPeanuts
        '
        Me.btnSPeanuts.BackColor = System.Drawing.Color.Aquamarine
        Me.btnSPeanuts.Location = New System.Drawing.Point(69, 371)
        Me.btnSPeanuts.Name = "btnSPeanuts"
        Me.btnSPeanuts.Size = New System.Drawing.Size(124, 23)
        Me.btnSPeanuts.TabIndex = 11
        Me.btnSPeanuts.Text = "Salted Peanuts"
        Me.btnSPeanuts.UseVisualStyleBackColor = False
        '
        'btnSPretzels
        '
        Me.btnSPretzels.BackColor = System.Drawing.Color.Aquamarine
        Me.btnSPretzels.Location = New System.Drawing.Point(263, 371)
        Me.btnSPretzels.Name = "btnSPretzels"
        Me.btnSPretzels.Size = New System.Drawing.Size(124, 23)
        Me.btnSPretzels.TabIndex = 12
        Me.btnSPretzels.Text = "Mini Pretzels"
        Me.btnSPretzels.UseVisualStyleBackColor = False
        '
        'frmAirlineSnack
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(456, 513)
        Me.Controls.Add(Me.btnSPretzels)
        Me.Controls.Add(Me.btnSPeanuts)
        Me.Controls.Add(Me.picSPretzels)
        Me.Controls.Add(Me.picSPeanuts)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblConfirmation)
        Me.Controls.Add(Me.lblInstructions)
        Me.Controls.Add(Me.btnCookies)
        Me.Controls.Add(Me.btnSelect)
        Me.Controls.Add(Me.btnCC)
        Me.Controls.Add(Me.picCookies)
        Me.Controls.Add(Me.picCC)
        Me.Controls.Add(Me.lblHeading)
        Me.Name = "frmAirlineSnack"
        Me.Text = "Airline Snacks"
        CType(Me.picSPretzels, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSPeanuts, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCookies, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCC, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblHeading As Label
    Friend WithEvents picCC As PictureBox
    Friend WithEvents picCookies As PictureBox
    Friend WithEvents btnCC As Button
    Friend WithEvents btnSelect As Button
    Friend WithEvents btnCookies As Button
    Friend WithEvents lblInstructions As Label
    Friend WithEvents lblConfirmation As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents picSPeanuts As PictureBox
    Friend WithEvents picSPretzels As PictureBox
    Friend WithEvents btnSPeanuts As Button
    Friend WithEvents btnSPretzels As Button
End Class
