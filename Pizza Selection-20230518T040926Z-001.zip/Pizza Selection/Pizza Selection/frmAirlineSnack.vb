﻿' Program Name: Airline Snack Selection
' Developer:    Christopher I.
' Date:         August 31, 2017
' Purpose:      This application displays airline snacks.
'               User can select one snack and close
'               the application using am exit button.

Public Class frmAirlineSnack
    Private Sub btnCC_Click(sender As Object, e As EventArgs) Handles btnCC.Click
        'When the user clicks the Cheese and Crackers button,
        'it shows the Cheese and Crackers picture.
        picCC.Visible = True
        picCookies.Visible = False
        picSPeanuts.Visible = False
        picSPretzels.Visible = False
        btnSelect.Enabled = True
    End Sub
    Private Sub btnCookies_Click(sender As Object, e As EventArgs) Handles btnCookies.Click
        'When the user clicks the Cookies button,
        'it shows the Cookies picture.
        picCC.Visible = False
        picCookies.Visible = True
        picSPeanuts.Visible = False
        picSPretzels.Visible = False
        btnSelect.Enabled = True
    End Sub
    Private Sub btnSPeanuts_Click(sender As Object, e As EventArgs) Handles btnSPeanuts.Click
        'When user clicks the Salted Peanuts button,
        'it shows the Peanuts picture and hides other pictures.
        picCC.Visible = False
        picCookies.Visible = False
        picSPeanuts.Visible = True
        picSPretzels.Visible = False
        btnSelect.Enabled = True
    End Sub
    Private Sub btnSPretzels_Click(sender As Object, e As EventArgs) Handles btnSPretzels.Click
        'When user clicks the Salted Pretzels button,
        'it shows the Pretzels picture and hides other pictures.
        picCC.Visible = False
        picCookies.Visible = False
        picSPeanuts.Visible = False
        picSPretzels.Visible = True
        btnSelect.Enabled = True
    End Sub

    Private Sub btnSelect_Click(sender As Object, e As EventArgs) Handles btnSelect.Click
        'When user clicks the Select button 
        'it disables all other buttons And enables the Exit button.
        btnCC.Enabled = False
        btnCookies.Enabled = False
        btnSPeanuts.Enabled = False
        btnSPretzels.Enabled = False
        lblInstructions.Visible = False
        lblConfirmation.Visible = True
        btnSelect.Enabled = False
        btnExit.Enabled = True
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'It closes the application. What else would it do?
        Close()
    End Sub
End Class
