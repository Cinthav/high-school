﻿' Program Name: Nest Egg Application
' Date Created: December 15, 2017
' Author: Christopher Inthavong 
' Purpose: This application takes the three inputs of the user
'(down payment, interest rate, and years saved)
' to calculate the amount of money saved over the course of time.
Option Strict On
Public Class frmNestEgg
    Private Sub frmNestEgg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' When the application starts, focus is set in the Principal 
        'Text box and all the text boxes are cleared.
        txtPrincipal.Focus()
        txtInterest.Text = ""
        txtPrincipal.Text = ""
        txtYears.Text = ""
    End Sub
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Assigns variables
        Dim decPrincipal As Decimal
        Dim decInterest As Decimal
        Dim decYears As Decimal
        Dim decCounter As Decimal = 1
        Dim strTotal As String
        'Checks if values entered into text boxes if they are > 0 and if they are numeric
        If IsNumeric(txtPrincipal.Text) And IsNumeric(txtInterest.Text) And IsNumeric(txtYears.Text) Then
            decPrincipal = Convert.ToDecimal(txtPrincipal.Text)
            decInterest = Convert.ToDecimal(txtInterest.Text)
            decYears = Convert.ToDecimal(txtYears.Text)
            If decPrincipal >= 1 And decInterest >= 0.001 And decYears >= 1 Then
                Do Until decCounter = decYears + 1 'Loop starts here. It does the math
                    decPrincipal = decPrincipal + (decPrincipal * decInterest)
                    strTotal = decPrincipal.ToString("C")
                    lstSavings.Items.Add(" Year " & decCounter & " Total " & " " & strTotal)
                    decCounter += 1
                Loop 'Loop/math stops here.
            Else
                'Error message shows if values entered are not > 0
                MsgBox("One of the values you entered is not a number greater than zero.")
            End If
        Else
            'Error message if user enters a(n) non-numeric value(s)
            MsgBox("One of your values is not numeric, please enter a(n) real number(s).")
        End If
    End Sub

    Private Sub mnuClear_Click(sender As Object, e As EventArgs) Handles mnuClear.Click
        'Clears the text boxes when the Clear button in the file menu is clicked.
        txtInterest.Text = ""
        txtPrincipal.Text = ""
        txtYears.Text = ""
        lstSavings.Items.Clear()
    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        ' When the user clicks the Exit button in the File menu strip,
        ' the application is closed.
        Me.Close()
    End Sub
End Class