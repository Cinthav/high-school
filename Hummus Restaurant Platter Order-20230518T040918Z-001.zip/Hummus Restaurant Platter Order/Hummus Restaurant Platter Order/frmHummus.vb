﻿'Name:    Hummus Platter Application
'Creator: Christopher Inthavong
'Date:    9/25/2017
'Purpose: This application allows the user to choose from 5 different types
'         of hummus, 3 types of pita bread, and 2 toppings. It also displays
'         the total cost along with the items ordered. The user can also enter
'         the amount of loyalty points to use for a 5% discount per 10 points.

Option Strict On
Public Class frmHummus
    Dim decCost As Decimal

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Calculates the total cost for the order along
        'with adding a discount based off loyalty points.

        Dim intLoyalty As Integer
        Dim decLoyaltyPoints As Decimal
        Dim decDiscount As Decimal
        Dim decDiscountAmount As Decimal
        Dim decTotalCost As Decimal
        Dim decCost As Decimal
        Dim strBread As String
        Dim strHummus As String
        Dim strToppings As String
        Dim strCost As String

        'Makes sure loyalty points is numeric
        If IsNumeric(txtLoyalty.Text) Then


            'Makes sure loyalty points is above 0 and applies discount.
            If intLoyalty >= 0 Then
                If radChipotleLime.Checked Then
                    decCost = 10D
                    strHummus = "ChipotleLime Hummus"
                ElseIf radHummus.Checked Then
                    decCost = 6D
                    strHummus = "Original Hummus"
                ElseIf radLemon.Checked Then
                    decCost = 8D
                    strHummus = "Lemon Thyme Hummus"
                ElseIf radOlive.Checked Then
                    decCost = 9D
                    strHummus = "Spiced Olive Salami Hummus"
                ElseIf radSpicy.Checked Then
                    decCost = 8D
                    strHummus = "Spicy Black Bean Hummus"
                End If
                'Assigning bread value
                If radOriginal.Checked Then

                    strBread = "Original Pita Bread"
                ElseIf radMulti.Checked Then
                    strBread = "Multi-Grain Bread"
                ElseIf radBurnt.Checked Then
                    strBread = "Slightly Burnt Bread"
                End If
                If radTomatoes.Checked And radCheese.Checked Then
                    strToppings = "Cheese and Tomatoes"
                ElseIf radTomatoes.Checked Then
                    strToppings = "Tomatoes"
                ElseIf radCheese.Checked Then
                    strToppings = "Cheese"
                Else
                    strToppings = "None"
                End If
            Else
                MsgBox("Choose a hummus and enter loyalty points.")
            End If
        Else
            MsgBox("Enter a numeric value")
        End If
        lblOrder.Text = strCost & ", " & strHummus & ", " & strBread & ", " & strToppings
        decDiscount = decCost * decDiscountAmount
        decTotalCost = decCost - decDiscount
        strCost = Convert.ToString(decTotalCost)
    End Sub

    Private Sub frmHummus_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtLoyalty.Focus()
        lblOrder.Text = ""
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        radChipotleLime.Checked = True
        radBurnt.Checked = False
        radCheese.Checked = False
        radHummus.Checked = False
        radLemon.Checked = False
        radMulti.Checked = False
        radOlive.Checked = False
        radOriginal.Checked = False
        radSpicy.Checked = False
        radTomatoes.Checked = False
        txtLoyalty.Text = ("")
        lblOrder.Text = ""
    End Sub
End Class
