﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHummus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpBread = New System.Windows.Forms.GroupBox()
        Me.radBurnt = New System.Windows.Forms.RadioButton()
        Me.radMulti = New System.Windows.Forms.RadioButton()
        Me.radOriginal = New System.Windows.Forms.RadioButton()
        Me.grpToppings = New System.Windows.Forms.GroupBox()
        Me.radCheese = New System.Windows.Forms.RadioButton()
        Me.radTomatoes = New System.Windows.Forms.RadioButton()
        Me.grpHummus = New System.Windows.Forms.GroupBox()
        Me.radSpicy = New System.Windows.Forms.RadioButton()
        Me.radOlive = New System.Windows.Forms.RadioButton()
        Me.radLemon = New System.Windows.Forms.RadioButton()
        Me.radHummus = New System.Windows.Forms.RadioButton()
        Me.radChipotleLime = New System.Windows.Forms.RadioButton()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblLoyalty = New System.Windows.Forms.Label()
        Me.picHummus = New System.Windows.Forms.PictureBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.txtLoyalty = New System.Windows.Forms.TextBox()
        Me.lblReceipt = New System.Windows.Forms.Label()
        Me.lblOrder = New System.Windows.Forms.Label()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.grpBread.SuspendLayout()
        Me.grpToppings.SuspendLayout()
        Me.grpHummus.SuspendLayout()
        CType(Me.picHummus, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grpBread
        '
        Me.grpBread.Controls.Add(Me.radBurnt)
        Me.grpBread.Controls.Add(Me.radMulti)
        Me.grpBread.Controls.Add(Me.radOriginal)
        Me.grpBread.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpBread.Location = New System.Drawing.Point(12, 237)
        Me.grpBread.Name = "grpBread"
        Me.grpBread.Size = New System.Drawing.Size(200, 100)
        Me.grpBread.TabIndex = 0
        Me.grpBread.TabStop = False
        Me.grpBread.Text = "Pita Breads (No additional cost.)"
        '
        'radBurnt
        '
        Me.radBurnt.AutoSize = True
        Me.radBurnt.Location = New System.Drawing.Point(6, 69)
        Me.radBurnt.Name = "radBurnt"
        Me.radBurnt.Size = New System.Drawing.Size(121, 18)
        Me.radBurnt.TabIndex = 2
        Me.radBurnt.Text = "Slightly Burnt Pita"
        Me.radBurnt.UseVisualStyleBackColor = True
        '
        'radMulti
        '
        Me.radMulti.AutoSize = True
        Me.radMulti.Location = New System.Drawing.Point(6, 45)
        Me.radMulti.Name = "radMulti"
        Me.radMulti.Size = New System.Drawing.Size(140, 18)
        Me.radMulti.TabIndex = 1
        Me.radMulti.Text = "Multi-Grain Pita Bread"
        Me.radMulti.UseVisualStyleBackColor = True
        '
        'radOriginal
        '
        Me.radOriginal.AutoSize = True
        Me.radOriginal.Location = New System.Drawing.Point(6, 21)
        Me.radOriginal.Name = "radOriginal"
        Me.radOriginal.Size = New System.Drawing.Size(127, 18)
        Me.radOriginal.TabIndex = 0
        Me.radOriginal.Text = "Original Pita Bread "
        Me.radOriginal.UseVisualStyleBackColor = True
        '
        'grpToppings
        '
        Me.grpToppings.Controls.Add(Me.radCheese)
        Me.grpToppings.Controls.Add(Me.radTomatoes)
        Me.grpToppings.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpToppings.Location = New System.Drawing.Point(12, 343)
        Me.grpToppings.Name = "grpToppings"
        Me.grpToppings.Size = New System.Drawing.Size(200, 100)
        Me.grpToppings.TabIndex = 1
        Me.grpToppings.TabStop = False
        Me.grpToppings.Text = "Toppings (No additional cost)"
        '
        'radCheese
        '
        Me.radCheese.AutoSize = True
        Me.radCheese.Location = New System.Drawing.Point(6, 56)
        Me.radCheese.Name = "radCheese"
        Me.radCheese.Size = New System.Drawing.Size(122, 18)
        Me.radCheese.TabIndex = 1
        Me.radCheese.Text = "Shredded Cheese"
        Me.radCheese.UseVisualStyleBackColor = True
        '
        'radTomatoes
        '
        Me.radTomatoes.AutoSize = True
        Me.radTomatoes.Location = New System.Drawing.Point(6, 32)
        Me.radTomatoes.Name = "radTomatoes"
        Me.radTomatoes.Size = New System.Drawing.Size(114, 18)
        Me.radTomatoes.TabIndex = 0
        Me.radTomatoes.Text = "Diced Tomatoes"
        Me.radTomatoes.UseVisualStyleBackColor = True
        '
        'grpHummus
        '
        Me.grpHummus.Controls.Add(Me.radSpicy)
        Me.grpHummus.Controls.Add(Me.radOlive)
        Me.grpHummus.Controls.Add(Me.radLemon)
        Me.grpHummus.Controls.Add(Me.radHummus)
        Me.grpHummus.Controls.Add(Me.radChipotleLime)
        Me.grpHummus.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpHummus.Location = New System.Drawing.Point(12, 77)
        Me.grpHummus.Name = "grpHummus"
        Me.grpHummus.Size = New System.Drawing.Size(223, 154)
        Me.grpHummus.TabIndex = 2
        Me.grpHummus.TabStop = False
        Me.grpHummus.Text = "Hummus (Can only select one)"
        '
        'radSpicy
        '
        Me.radSpicy.AutoSize = True
        Me.radSpicy.Location = New System.Drawing.Point(6, 121)
        Me.radSpicy.Name = "radSpicy"
        Me.radSpicy.Size = New System.Drawing.Size(202, 18)
        Me.radSpicy.TabIndex = 4
        Me.radSpicy.Text = "Spicy Black Bean Hummus $8.00"
        Me.radSpicy.UseVisualStyleBackColor = True
        '
        'radOlive
        '
        Me.radOlive.AutoSize = True
        Me.radOlive.Location = New System.Drawing.Point(6, 97)
        Me.radOlive.Name = "radOlive"
        Me.radOlive.Size = New System.Drawing.Size(215, 18)
        Me.radOlive.TabIndex = 3
        Me.radOlive.Text = "Spiced Olive Salami Hummus $9.00"
        Me.radOlive.UseVisualStyleBackColor = True
        '
        'radLemon
        '
        Me.radLemon.AutoSize = True
        Me.radLemon.Location = New System.Drawing.Point(6, 73)
        Me.radLemon.Name = "radLemon"
        Me.radLemon.Size = New System.Drawing.Size(184, 18)
        Me.radLemon.TabIndex = 2
        Me.radLemon.Text = "Lemon Tyme Hummus $8.00"
        Me.radLemon.UseVisualStyleBackColor = True
        '
        'radHummus
        '
        Me.radHummus.AutoSize = True
        Me.radHummus.Location = New System.Drawing.Point(6, 49)
        Me.radHummus.Name = "radHummus"
        Me.radHummus.Size = New System.Drawing.Size(145, 18)
        Me.radHummus.TabIndex = 1
        Me.radHummus.Text = "Classic Hummus $6.00"
        Me.radHummus.UseVisualStyleBackColor = True
        '
        'radChipotleLime
        '
        Me.radChipotleLime.AutoSize = True
        Me.radChipotleLime.Checked = True
        Me.radChipotleLime.Location = New System.Drawing.Point(6, 25)
        Me.radChipotleLime.Name = "radChipotleLime"
        Me.radChipotleLime.Size = New System.Drawing.Size(192, 18)
        Me.radChipotleLime.TabIndex = 0
        Me.radChipotleLime.TabStop = True
        Me.radChipotleLime.Text = "Chipotle Lime Hummus $10.00"
        Me.radChipotleLime.UseVisualStyleBackColor = True
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(203, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(169, 50)
        Me.lblTitle.TabIndex = 3
        Me.lblTitle.Text = "Some Hummus" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Platters"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblLoyalty
        '
        Me.lblLoyalty.AutoSize = True
        Me.lblLoyalty.Location = New System.Drawing.Point(12, 488)
        Me.lblLoyalty.Name = "lblLoyalty"
        Me.lblLoyalty.Size = New System.Drawing.Size(75, 13)
        Me.lblLoyalty.TabIndex = 4
        Me.lblLoyalty.Text = "Loyalty Points:"
        '
        'picHummus
        '
        Me.picHummus.Image = Global.Hummus_Restaurant_Platter_Order.My.Resources.Resources.planetHummus
        Me.picHummus.Location = New System.Drawing.Point(331, 412)
        Me.picHummus.Name = "picHummus"
        Me.picHummus.Size = New System.Drawing.Size(243, 149)
        Me.picHummus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picHummus.TabIndex = 5
        Me.picHummus.TabStop = False
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(12, 513)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 6
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'txtLoyalty
        '
        Me.txtLoyalty.Location = New System.Drawing.Point(94, 485)
        Me.txtLoyalty.Name = "txtLoyalty"
        Me.txtLoyalty.Size = New System.Drawing.Size(64, 20)
        Me.txtLoyalty.TabIndex = 7
        '
        'lblReceipt
        '
        Me.lblReceipt.AutoSize = True
        Me.lblReceipt.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReceipt.Location = New System.Drawing.Point(380, 62)
        Me.lblReceipt.Name = "lblReceipt"
        Me.lblReceipt.Size = New System.Drawing.Size(55, 16)
        Me.lblReceipt.TabIndex = 8
        Me.lblReceipt.Text = "Receipt:"
        '
        'lblOrder
        '
        Me.lblOrder.AutoSize = True
        Me.lblOrder.Location = New System.Drawing.Point(241, 282)
        Me.lblOrder.Name = "lblOrder"
        Me.lblOrder.Size = New System.Drawing.Size(57, 13)
        Me.lblOrder.TabIndex = 9
        Me.lblOrder.Text = "xxxxxxxxxx"
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Location = New System.Drawing.Point(241, 93)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(330, 13)
        Me.lblInstructions.TabIndex = 10
        Me.lblInstructions.Text = "Choose one Hummus, a pita bread, and if you want a topping or two."
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(94, 513)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 11
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'frmHummus
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PapayaWhip
        Me.ClientSize = New System.Drawing.Size(575, 560)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.lblInstructions)
        Me.Controls.Add(Me.lblOrder)
        Me.Controls.Add(Me.lblReceipt)
        Me.Controls.Add(Me.txtLoyalty)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.picHummus)
        Me.Controls.Add(Me.lblLoyalty)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.grpHummus)
        Me.Controls.Add(Me.grpToppings)
        Me.Controls.Add(Me.grpBread)
        Me.Name = "frmHummus"
        Me.Text = "Some Hummus Restaurant"
        Me.grpBread.ResumeLayout(False)
        Me.grpBread.PerformLayout()
        Me.grpToppings.ResumeLayout(False)
        Me.grpToppings.PerformLayout()
        Me.grpHummus.ResumeLayout(False)
        Me.grpHummus.PerformLayout()
        CType(Me.picHummus, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpBread As GroupBox
    Friend WithEvents grpToppings As GroupBox
    Friend WithEvents grpHummus As GroupBox
    Friend WithEvents radSpicy As RadioButton
    Friend WithEvents radOlive As RadioButton
    Friend WithEvents radLemon As RadioButton
    Friend WithEvents radHummus As RadioButton
    Friend WithEvents radChipotleLime As RadioButton
    Friend WithEvents lblTitle As Label
    Friend WithEvents radMulti As RadioButton
    Friend WithEvents radOriginal As RadioButton
    Friend WithEvents radCheese As RadioButton
    Friend WithEvents radTomatoes As RadioButton
    Friend WithEvents radBurnt As RadioButton
    Friend WithEvents lblLoyalty As Label
    Friend WithEvents picHummus As PictureBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents txtLoyalty As TextBox
    Friend WithEvents lblReceipt As Label
    Friend WithEvents lblOrder As Label
    Friend WithEvents lblInstructions As Label
    Friend WithEvents btnClear As Button
End Class
