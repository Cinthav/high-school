﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmExerciseCalc
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtCurrentYear = New System.Windows.Forms.TextBox()
        Me.txtCurrentMonth = New System.Windows.Forms.TextBox()
        Me.txtCurrentDay = New System.Windows.Forms.TextBox()
        Me.txtBYear = New System.Windows.Forms.TextBox()
        Me.txtBDay = New System.Windows.Forms.TextBox()
        Me.txtBMonth = New System.Windows.Forms.TextBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.lblMonthA = New System.Windows.Forms.Label()
        Me.lblDayA = New System.Windows.Forms.Label()
        Me.lblYearA = New System.Windows.Forms.Label()
        Me.lblMonthB = New System.Windows.Forms.Label()
        Me.lblDayB = New System.Windows.Forms.Label()
        Me.lblYearB = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.lblCurrentDate = New System.Windows.Forms.Label()
        Me.lblBirthday = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtCurrentYear
        '
        Me.txtCurrentYear.Location = New System.Drawing.Point(141, 286)
        Me.txtCurrentYear.Name = "txtCurrentYear"
        Me.txtCurrentYear.Size = New System.Drawing.Size(47, 20)
        Me.txtCurrentYear.TabIndex = 0
        '
        'txtCurrentMonth
        '
        Me.txtCurrentMonth.Location = New System.Drawing.Point(141, 212)
        Me.txtCurrentMonth.Name = "txtCurrentMonth"
        Me.txtCurrentMonth.Size = New System.Drawing.Size(47, 20)
        Me.txtCurrentMonth.TabIndex = 1
        '
        'txtCurrentDay
        '
        Me.txtCurrentDay.Location = New System.Drawing.Point(141, 249)
        Me.txtCurrentDay.Name = "txtCurrentDay"
        Me.txtCurrentDay.Size = New System.Drawing.Size(47, 20)
        Me.txtCurrentDay.TabIndex = 2
        '
        'txtBYear
        '
        Me.txtBYear.Location = New System.Drawing.Point(275, 286)
        Me.txtBYear.Name = "txtBYear"
        Me.txtBYear.Size = New System.Drawing.Size(47, 20)
        Me.txtBYear.TabIndex = 3
        '
        'txtBDay
        '
        Me.txtBDay.Location = New System.Drawing.Point(275, 249)
        Me.txtBDay.Name = "txtBDay"
        Me.txtBDay.Size = New System.Drawing.Size(47, 20)
        Me.txtBDay.TabIndex = 4
        '
        'txtBMonth
        '
        Me.txtBMonth.Location = New System.Drawing.Point(274, 212)
        Me.txtBMonth.Name = "txtBMonth"
        Me.txtBMonth.Size = New System.Drawing.Size(47, 20)
        Me.txtBMonth.TabIndex = 5
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(109, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(190, 50)
        Me.lblTitle.TabIndex = 6
        Me.lblTitle.Text = "Lifetime Exercise" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Calculator"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstructions.Location = New System.Drawing.Point(47, 59)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(315, 40)
        Me.lblInstructions.TabIndex = 7
        Me.lblInstructions.Text = "Enter your name, birthday, and current date" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " in the appropriate boxes"
        Me.lblInstructions.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblMonthA
        '
        Me.lblMonthA.AutoSize = True
        Me.lblMonthA.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMonthA.Location = New System.Drawing.Point(76, 210)
        Me.lblMonthA.Name = "lblMonthA"
        Me.lblMonthA.Size = New System.Drawing.Size(59, 19)
        Me.lblMonthA.TabIndex = 8
        Me.lblMonthA.Text = "Month:"
        '
        'lblDayA
        '
        Me.lblDayA.AutoSize = True
        Me.lblDayA.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDayA.Location = New System.Drawing.Point(93, 247)
        Me.lblDayA.Name = "lblDayA"
        Me.lblDayA.Size = New System.Drawing.Size(42, 19)
        Me.lblDayA.TabIndex = 9
        Me.lblDayA.Text = "Day:"
        '
        'lblYearA
        '
        Me.lblYearA.AutoSize = True
        Me.lblYearA.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYearA.Location = New System.Drawing.Point(88, 284)
        Me.lblYearA.Name = "lblYearA"
        Me.lblYearA.Size = New System.Drawing.Size(47, 19)
        Me.lblYearA.TabIndex = 10
        Me.lblYearA.Text = "Year:"
        '
        'lblMonthB
        '
        Me.lblMonthB.AutoSize = True
        Me.lblMonthB.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMonthB.Location = New System.Drawing.Point(210, 210)
        Me.lblMonthB.Name = "lblMonthB"
        Me.lblMonthB.Size = New System.Drawing.Size(59, 19)
        Me.lblMonthB.TabIndex = 11
        Me.lblMonthB.Text = "Month:"
        '
        'lblDayB
        '
        Me.lblDayB.AutoSize = True
        Me.lblDayB.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDayB.Location = New System.Drawing.Point(227, 247)
        Me.lblDayB.Name = "lblDayB"
        Me.lblDayB.Size = New System.Drawing.Size(42, 19)
        Me.lblDayB.TabIndex = 12
        Me.lblDayB.Text = "Day:"
        '
        'lblYearB
        '
        Me.lblYearB.AutoSize = True
        Me.lblYearB.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYearB.Location = New System.Drawing.Point(222, 284)
        Me.lblYearB.Name = "lblYearB"
        Me.lblYearB.Size = New System.Drawing.Size(47, 19)
        Me.lblYearB.TabIndex = 13
        Me.lblYearB.Text = "Year:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(137, 128)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(181, 20)
        Me.txtName.TabIndex = 14
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(75, 129)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(56, 19)
        Me.lblName.TabIndex = 15
        Me.lblName.Text = "Name:"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(60, 393)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 16
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(167, 393)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 17
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(274, 393)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 18
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Location = New System.Drawing.Point(123, 443)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(12, 13)
        Me.lblResult.TabIndex = 19
        Me.lblResult.Text = "x"
        '
        'lblCurrentDate
        '
        Me.lblCurrentDate.AutoSize = True
        Me.lblCurrentDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrentDate.Location = New System.Drawing.Point(92, 173)
        Me.lblCurrentDate.Name = "lblCurrentDate"
        Me.lblCurrentDate.Size = New System.Drawing.Size(96, 36)
        Me.lblCurrentDate.TabIndex = 20
        Me.lblCurrentDate.Text = "Current Date:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "x/xx/xxxx"
        Me.lblCurrentDate.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblBirthday
        '
        Me.lblBirthday.AutoSize = True
        Me.lblBirthday.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBirthday.Location = New System.Drawing.Point(245, 173)
        Me.lblBirthday.Name = "lblBirthday"
        Me.lblBirthday.Size = New System.Drawing.Size(77, 36)
        Me.lblBirthday.TabIndex = 21
        Me.lblBirthday.Text = "Birth Date:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "x/xx/xxxx"
        Me.lblBirthday.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'frmExerciseCalc
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(408, 477)
        Me.Controls.Add(Me.lblBirthday)
        Me.Controls.Add(Me.lblCurrentDate)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblYearB)
        Me.Controls.Add(Me.lblDayB)
        Me.Controls.Add(Me.lblMonthB)
        Me.Controls.Add(Me.lblYearA)
        Me.Controls.Add(Me.lblDayA)
        Me.Controls.Add(Me.lblMonthA)
        Me.Controls.Add(Me.lblInstructions)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.txtBMonth)
        Me.Controls.Add(Me.txtBDay)
        Me.Controls.Add(Me.txtBYear)
        Me.Controls.Add(Me.txtCurrentDay)
        Me.Controls.Add(Me.txtCurrentMonth)
        Me.Controls.Add(Me.txtCurrentYear)
        Me.Name = "frmExerciseCalc"
        Me.Text = "Lifetime Exercise"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtCurrentYear As TextBox
    Friend WithEvents txtCurrentMonth As TextBox
    Friend WithEvents txtCurrentDay As TextBox
    Friend WithEvents txtBYear As TextBox
    Friend WithEvents txtBDay As TextBox
    Friend WithEvents txtBMonth As TextBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents lblInstructions As Label
    Friend WithEvents lblMonthA As Label
    Friend WithEvents lblDayA As Label
    Friend WithEvents lblYearA As Label
    Friend WithEvents lblMonthB As Label
    Friend WithEvents lblDayB As Label
    Friend WithEvents lblYearB As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents lblName As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents lblResult As Label
    Friend WithEvents lblCurrentDate As Label
    Friend WithEvents lblBirthday As Label
End Class
