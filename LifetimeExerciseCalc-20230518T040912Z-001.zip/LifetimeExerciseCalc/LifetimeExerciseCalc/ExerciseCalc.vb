﻿' Name:   Lifetime Fitness Calculator
' Author: Christopher Inthavong
' Date:   9/7/15
'Purpose: It trys to calculate how much exercise you 
'         gotten in your lifetime so far. Average numbers are
'         used in order to keep a constant flow of results.
'         (365 days in a year, 30 days per month, and 3 hours average per week of exercise).
Public Class frmExerciseCalc
    Const cintHours As Int32 = 3

    Private Sub frmExerciseCalc_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'I dont like commments
        txtName.Focus()
        txtName.Clear()
        txtCurrentMonth.Clear()
        txtBMonth.Clear()
        txtCurrentDay.Clear()
        txtBDay.Clear()
        txtCurrentYear.Clear()
        txtBYear.Clear()
        lblResult.Text = ""
    End Sub
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'It does Math
        Dim intCurrentYear As Integer
        Dim intBYear As Integer
        Dim intCurrentMonth As Integer
        Dim intBMonth As Integer
        Dim intCurrentDay As Integer
        Dim intBDay As Integer
        Dim intBMonthDays As Integer
        Dim intBDaysDays As Integer
        Dim intBYearDays As Integer
        Dim intMonthDays As Integer
        Dim intDaysDays As Integer
        Dim intYearsDays As Integer
        Dim intTotalDaysCurrent As Integer
        Dim intTotalDaysB As Integer
        Dim intAgeDays As Integer
        Dim intTotalHours As Integer
        Dim intTotalHoursExercised As Integer
        intCurrentYear = Convert.ToInt32(txtCurrentYear.Text)
        intCurrentDay = Convert.ToInt32(txtCurrentDay.Text)
        intCurrentMonth = Convert.ToInt32(txtCurrentMonth.Text)
        intBYear = Convert.ToInt32(txtBYear.Text)
        intBMonth = Convert.ToInt32(txtBMonth.Text)
        intBDay = Convert.ToInt32(txtBDay.Text)
        intBMonthDays = txtBMonth.Text * 30
        intBDaysDays = txtBDay.Text
        intBYearDays = txtBYear.Text * 365
        intYearsDays = txtCurrentYear.Text * 365
        intDaysDays = txtCurrentDay.Text
        intMonthDays = txtCurrentMonth.Text * 30
        intTotalDaysCurrent = intMonthDays + intDaysDays + intYearsDays
        intTotalDaysB = intBDaysDays + intBMonthDays + intBYearDays
        intAgeDays = intTotalDaysCurrent - intTotalDaysB
        intTotalHours = intAgeDays * 24
        intTotalHoursExercised = intTotalHours * 3
        lblResult.Text = "You have exercised " & Convert.ToString(intTotalHoursExercised) & " hours. "

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'It closes the application
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clears stuff
        txtName.Text = ""
        txtCurrentMonth.Text = ""
        txtBMonth.Text = ""
        txtCurrentDay.Text = ""
        txtBDay.Text = ""
        txtCurrentYear.Text = ""
        txtBYear.Text = ""
        lblResult.Text = ""
    End Sub
End Class
