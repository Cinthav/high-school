﻿Option Strict On
Public Class frmMultiplication
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intCounter, intInput, intAnswer, intRange As Integer
        If IsNumeric(txtInput.Text) And IsNumeric(txtRange.Text) Then
            intInput = Convert.ToInt32(txtInput.Text)
            intRange = Convert.ToInt32(txtRange.Text)
            If intInput > 0 And intRange > 0 Then
                For intCounter = 1 To intRange
                    intAnswer = intInput * intCounter
                    lstTable.Items.Add(intInput & " x " & intCounter & " = " & intAnswer)
                Next
                btnCalculate.Enabled = False
            Else
                MsgBox("Enter a positive value.",, "Input Error")
                txtInput.Clear()
                txtRange.Clear()
            End If
        Else
            MsgBox("Enter a numeric value.",, "Input Error")
            txtInput.Clear()
            txtRange.Clear()
        End If
    End Sub
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtInput.Clear()
        lstTable.Items.Clear()
        btnCalculate.Enabled = True
        txtRange.Clear()
    End Sub
End Class