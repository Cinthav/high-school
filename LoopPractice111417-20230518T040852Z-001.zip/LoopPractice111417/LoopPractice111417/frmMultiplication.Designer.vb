﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMultiplication
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.lstTable = New System.Windows.Forms.ListBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.txtRange = New System.Windows.Forms.TextBox()
        Me.lblInput = New System.Windows.Forms.Label()
        Me.lblUpperLimit = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.Location = New System.Drawing.Point(74, 26)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(210, 23)
        Me.lblHeading.TabIndex = 0
        Me.lblHeading.Text = "Multiplication Tables"
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(115, 78)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(44, 20)
        Me.txtInput.TabIndex = 1
        Me.txtInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lstTable
        '
        Me.lstTable.FormattingEnabled = True
        Me.lstTable.Location = New System.Drawing.Point(82, 139)
        Me.lstTable.Name = "lstTable"
        Me.lstTable.Size = New System.Drawing.Size(194, 251)
        Me.lstTable.TabIndex = 2
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(100, 396)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 3
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(183, 396)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'txtRange
        '
        Me.txtRange.Location = New System.Drawing.Point(257, 78)
        Me.txtRange.Name = "txtRange"
        Me.txtRange.Size = New System.Drawing.Size(44, 20)
        Me.txtRange.TabIndex = 5
        Me.txtRange.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblInput
        '
        Me.lblInput.AutoSize = True
        Me.lblInput.Location = New System.Drawing.Point(12, 81)
        Me.lblInput.Name = "lblInput"
        Me.lblInput.Size = New System.Drawing.Size(97, 13)
        Me.lblInput.TabIndex = 6
        Me.lblInput.Text = "Number to Multiply:"
        '
        'lblUpperLimit
        '
        Me.lblUpperLimit.AutoSize = True
        Me.lblUpperLimit.Location = New System.Drawing.Point(188, 81)
        Me.lblUpperLimit.Name = "lblUpperLimit"
        Me.lblUpperLimit.Size = New System.Drawing.Size(63, 13)
        Me.lblUpperLimit.TabIndex = 7
        Me.lblUpperLimit.Text = "Upper Limit:"
        '
        'frmMultiplication
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnClear
        Me.ClientSize = New System.Drawing.Size(358, 431)
        Me.Controls.Add(Me.lblUpperLimit)
        Me.Controls.Add(Me.lblInput)
        Me.Controls.Add(Me.txtRange)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lstTable)
        Me.Controls.Add(Me.txtInput)
        Me.Controls.Add(Me.lblHeading)
        Me.Name = "frmMultiplication"
        Me.Text = "Loop Practice"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblHeading As Label
    Friend WithEvents txtInput As TextBox
    Friend WithEvents lstTable As ListBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents txtRange As TextBox
    Friend WithEvents lblInput As Label
    Friend WithEvents lblUpperLimit As Label
End Class
