﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOnlineBank
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.btnFinish = New System.Windows.Forms.Button()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.pnlChoices = New System.Windows.Forms.GroupBox()
        Me.radCheck = New System.Windows.Forms.RadioButton()
        Me.radDeposit = New System.Windows.Forms.RadioButton()
        Me.radWithdraw = New System.Windows.Forms.RadioButton()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lblHow = New System.Windows.Forms.Label()
        Me.lblBalance = New System.Windows.Forms.Label()
        Me.btnContinue = New System.Windows.Forms.Button()
        Me.chkInterest = New System.Windows.Forms.CheckBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.pnlTransactions = New System.Windows.Forms.Panel()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lblCheck = New System.Windows.Forms.Label()
        Me.lblHowTo = New System.Windows.Forms.Label()
        Me.txtCheck = New System.Windows.Forms.TextBox()
        Me.txtBalance = New System.Windows.Forms.MaskedTextBox()
        Me.lstTransactions = New System.Windows.Forms.ListBox()
        Me.lblTransactions = New System.Windows.Forms.Label()
        Me.pnlChoices.SuspendLayout()
        Me.pnlTransactions.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Arial Narrow", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(64, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(195, 31)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "The Online Bank "
        '
        'btnFinish
        '
        Me.btnFinish.Font = New System.Drawing.Font("Arial Narrow", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFinish.Location = New System.Drawing.Point(102, 451)
        Me.btnFinish.Name = "btnFinish"
        Me.btnFinish.Size = New System.Drawing.Size(118, 23)
        Me.btnFinish.TabIndex = 1
        Me.btnFinish.Text = "I'm Finished"
        Me.btnFinish.UseVisualStyleBackColor = True
        Me.btnFinish.Visible = False
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Location = New System.Drawing.Point(54, 216)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(215, 13)
        Me.lblInstructions.TabIndex = 2
        Me.lblInstructions.Text = "Choose from the different services available."
        Me.lblInstructions.Visible = False
        '
        'pnlChoices
        '
        Me.pnlChoices.BackColor = System.Drawing.Color.White
        Me.pnlChoices.Controls.Add(Me.radCheck)
        Me.pnlChoices.Controls.Add(Me.radDeposit)
        Me.pnlChoices.Controls.Add(Me.radWithdraw)
        Me.pnlChoices.Location = New System.Drawing.Point(88, 232)
        Me.pnlChoices.Name = "pnlChoices"
        Me.pnlChoices.Size = New System.Drawing.Size(146, 107)
        Me.pnlChoices.TabIndex = 4
        Me.pnlChoices.TabStop = False
        Me.pnlChoices.Visible = False
        '
        'radCheck
        '
        Me.radCheck.AutoSize = True
        Me.radCheck.Location = New System.Drawing.Point(26, 68)
        Me.radCheck.Name = "radCheck"
        Me.radCheck.Size = New System.Drawing.Size(95, 17)
        Me.radCheck.TabIndex = 2
        Me.radCheck.TabStop = True
        Me.radCheck.Text = "Check Deposit"
        Me.radCheck.UseVisualStyleBackColor = True
        '
        'radDeposit
        '
        Me.radDeposit.AutoSize = True
        Me.radDeposit.Location = New System.Drawing.Point(26, 45)
        Me.radDeposit.Name = "radDeposit"
        Me.radDeposit.Size = New System.Drawing.Size(61, 17)
        Me.radDeposit.TabIndex = 1
        Me.radDeposit.TabStop = True
        Me.radDeposit.Text = "Deposit" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.radDeposit.UseVisualStyleBackColor = True
        '
        'radWithdraw
        '
        Me.radWithdraw.AutoSize = True
        Me.radWithdraw.Location = New System.Drawing.Point(26, 22)
        Me.radWithdraw.Name = "radWithdraw"
        Me.radWithdraw.Size = New System.Drawing.Size(70, 17)
        Me.radWithdraw.TabIndex = 0
        Me.radWithdraw.TabStop = True
        Me.radWithdraw.Text = "Withdraw"
        Me.radWithdraw.UseVisualStyleBackColor = True
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Location = New System.Drawing.Point(56, 111)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(49, 13)
        Me.lbl1.TabIndex = 6
        Me.lbl1.Text = "Balance:"
        '
        'lblHow
        '
        Me.lblHow.AutoSize = True
        Me.lblHow.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHow.Location = New System.Drawing.Point(24, 47)
        Me.lblHow.Name = "lblHow"
        Me.lblHow.Size = New System.Drawing.Size(275, 30)
        Me.lblHow.TabIndex = 7
        Me.lblHow.Text = "Enter your account's starting balance and choose" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " whether your account has a mon" &
    "thly interest rate."
        Me.lblHow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblBalance
        '
        Me.lblBalance.AutoSize = True
        Me.lblBalance.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBalance.Location = New System.Drawing.Point(54, 179)
        Me.lblBalance.Name = "lblBalance"
        Me.lblBalance.Size = New System.Drawing.Size(295, 18)
        Me.lblBalance.TabIndex = 8
        Me.lblBalance.Text = "Your balance is $xxxxxxxxxxxx.xx" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.lblBalance.Visible = False
        '
        'btnContinue
        '
        Me.btnContinue.Location = New System.Drawing.Point(124, 134)
        Me.btnContinue.Name = "btnContinue"
        Me.btnContinue.Size = New System.Drawing.Size(75, 23)
        Me.btnContinue.TabIndex = 9
        Me.btnContinue.Text = "Continue"
        Me.btnContinue.UseVisualStyleBackColor = True
        '
        'chkInterest
        '
        Me.chkInterest.AutoSize = True
        Me.chkInterest.Location = New System.Drawing.Point(217, 110)
        Me.chkInterest.Name = "chkInterest"
        Me.chkInterest.Size = New System.Drawing.Size(101, 17)
        Me.chkInterest.TabIndex = 10
        Me.chkInterest.Text = "Monthly Interest"
        Me.chkInterest.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(124, 480)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 17
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        Me.btnClear.Visible = False
        '
        'pnlTransactions
        '
        Me.pnlTransactions.BackColor = System.Drawing.Color.White
        Me.pnlTransactions.Controls.Add(Me.txtInput)
        Me.pnlTransactions.Controls.Add(Me.btnAdd)
        Me.pnlTransactions.Controls.Add(Me.lblCheck)
        Me.pnlTransactions.Controls.Add(Me.lblHowTo)
        Me.pnlTransactions.Controls.Add(Me.txtCheck)
        Me.pnlTransactions.Location = New System.Drawing.Point(61, 345)
        Me.pnlTransactions.Name = "pnlTransactions"
        Me.pnlTransactions.Size = New System.Drawing.Size(200, 100)
        Me.pnlTransactions.TabIndex = 3
        Me.pnlTransactions.Visible = False
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(93, 39)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(100, 20)
        Me.txtInput.TabIndex = 12
        Me.txtInput.Visible = False
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(41, 65)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(118, 23)
        Me.btnAdd.TabIndex = 15
        Me.btnAdd.Text = "Update Balance"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'lblCheck
        '
        Me.lblCheck.AutoSize = True
        Me.lblCheck.Location = New System.Drawing.Point(8, 42)
        Me.lblCheck.Name = "lblCheck"
        Me.lblCheck.Size = New System.Drawing.Size(81, 13)
        Me.lblCheck.TabIndex = 13
        Me.lblCheck.Text = "Check Number:"
        Me.lblCheck.Visible = False
        '
        'lblHowTo
        '
        Me.lblHowTo.AutoSize = True
        Me.lblHowTo.Location = New System.Drawing.Point(15, 16)
        Me.lblHowTo.Name = "lblHowTo"
        Me.lblHowTo.Size = New System.Drawing.Size(74, 13)
        Me.lblHowTo.TabIndex = 11
        Me.lblHowTo.Text = "Enter Amount:"
        Me.lblHowTo.Visible = False
        '
        'txtCheck
        '
        Me.txtCheck.Location = New System.Drawing.Point(93, 13)
        Me.txtCheck.Name = "txtCheck"
        Me.txtCheck.Size = New System.Drawing.Size(100, 20)
        Me.txtCheck.TabIndex = 14
        Me.txtCheck.Visible = False
        '
        'txtBalance
        '
        Me.txtBalance.Location = New System.Drawing.Point(111, 108)
        Me.txtBalance.Name = "txtBalance"
        Me.txtBalance.Size = New System.Drawing.Size(100, 20)
        Me.txtBalance.TabIndex = 18
        '
        'lstTransactions
        '
        Me.lstTransactions.FormattingEnabled = True
        Me.lstTransactions.Location = New System.Drawing.Point(318, 54)
        Me.lstTransactions.Name = "lstTransactions"
        Me.lstTransactions.Size = New System.Drawing.Size(219, 394)
        Me.lstTransactions.TabIndex = 19
        Me.lstTransactions.Visible = False
        '
        'lblTransactions
        '
        Me.lblTransactions.AutoSize = True
        Me.lblTransactions.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTransactions.Location = New System.Drawing.Point(371, 31)
        Me.lblTransactions.Name = "lblTransactions"
        Me.lblTransactions.Size = New System.Drawing.Size(112, 20)
        Me.lblTransactions.TabIndex = 20
        Me.lblTransactions.Text = "Transactions"
        Me.lblTransactions.Visible = False
        '
        'frmOnlineBank
        '
        Me.AcceptButton = Me.btnAdd
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Linen
        Me.ClientSize = New System.Drawing.Size(576, 504)
        Me.Controls.Add(Me.lblTransactions)
        Me.Controls.Add(Me.lstTransactions)
        Me.Controls.Add(Me.txtBalance)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.chkInterest)
        Me.Controls.Add(Me.btnContinue)
        Me.Controls.Add(Me.lblBalance)
        Me.Controls.Add(Me.pnlTransactions)
        Me.Controls.Add(Me.lblHow)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.pnlChoices)
        Me.Controls.Add(Me.lblInstructions)
        Me.Controls.Add(Me.btnFinish)
        Me.Controls.Add(Me.lblTitle)
        Me.Name = "frmOnlineBank"
        Me.Text = "Online Bank Statement"
        Me.pnlChoices.ResumeLayout(False)
        Me.pnlChoices.PerformLayout()
        Me.pnlTransactions.ResumeLayout(False)
        Me.pnlTransactions.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents btnFinish As Button
    Friend WithEvents lblInstructions As Label
    Friend WithEvents pnlChoices As GroupBox
    Friend WithEvents radDeposit As RadioButton
    Friend WithEvents radWithdraw As RadioButton
    Friend WithEvents radCheck As RadioButton
    Friend WithEvents lbl1 As Label
    Friend WithEvents lblHow As Label
    Friend WithEvents lblBalance As Label
    Friend WithEvents btnContinue As Button
    Friend WithEvents chkInterest As CheckBox
    Friend WithEvents btnClear As Button
    Friend WithEvents pnlTransactions As Panel
    Friend WithEvents txtInput As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents lblCheck As Label
    Friend WithEvents lblHowTo As Label
    Friend WithEvents txtCheck As TextBox
    Friend WithEvents txtBalance As MaskedTextBox
    Friend WithEvents lstTransactions As ListBox
    Friend WithEvents lblTransactions As Label
End Class
