﻿' Name:    Balance an Online Bank Statement (Case 7)
' Date:    3/1/18
' Author:  Chris I.
' Purpose: This application allows the user to balance their bank statement online.
'          The user has to enter their balance and check whether it has a monthly
'          interest rate. After, the user can choose from 3 services, deposit
'          withdraw, and check deposit. Finally, when the user finishes their 
'          transactions, it adds a monthly interest to the final balance (If indicated earlier).
Option Strict On
Public Class frmOnlineBank
    Dim decBalance As Decimal
    Const _cdecInterest As Decimal = 0.0015D
    Private Sub frmOnlineBank_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Loads the splash screen and prepares ther form.
        txtBalance.Focus()
        Threading.Thread.Sleep(400)
    End Sub
    Private Sub btnContinue_Click(sender As Object, e As EventArgs) Handles btnContinue.Click
        'Checks if balance entered is correct. Displays rest of form.
        Dim intValidityCheck As Integer
        Dim blnValidityCheck As Boolean = False
        Select Case intValidityCheck
            Case 0
                blnValidityCheck = ValidateNumber(blnValidityCheck)
        End Select
        If blnValidityCheck = True Then
            decBalance = Convert.ToDecimal(txtBalance.Text)
            'Borrowed from online cause textbook not great at helping. 
            Dim result As Integer = MessageBox.Show("Is the value entered correct? " & decBalance.ToString("C"), "Continue?", MessageBoxButtons.YesNo)
            If result = DialogResult.No Then
                txtBalance.Focus()
                blnValidityCheck = False
            ElseIf result = DialogResult.Yes Then
                lblBalance.Text = "Your balance is " & decBalance.ToString("C")
                btnContinue.Enabled = False
                lblBalance.Visible = True
                pnlChoices.Visible = True
                chkInterest.Enabled = False
                lblInstructions.Visible = True
                btnClear.Visible = True
                btnFinish.Visible = True
                lblTransactions.Visible = True
                lstTransactions.Visible = True
            End If
            'Source: https://stackoverflow.com/questions/2256909/messagebox-with-yesnocancel-no-cancel-triggers-same-event
        End If
    End Sub
    Private Function ValidateNumber(blnvalidityCheck As Boolean) As Boolean
        ' This procedure validates the value entered when the user clicks the Continue button.
        Dim strBalance As String = "Please enter a balance."
        Dim strError As String = "Please enter a valid balance."
        Dim strOverflow As String = "You can't be that rich. "
        Dim strMesssageBoxTitle As String = "Error"
        Try
            decBalance = Convert.ToDecimal(txtBalance.Text)
            If decBalance >= 0 Then
                blnvalidityCheck = True
            ElseIf decBalance <= 0 Then
                MsgBox(strBalance, , strMesssageBoxTitle)
                txtBalance.Focus()
                txtBalance.Clear()
            Else
                MsgBox(strBalance, , strMesssageBoxTitle)
                txtBalance.Focus()
                txtBalance.Clear()
            End If
        Catch Exception As FormatException
            MsgBox(strError, , strMesssageBoxTitle)
            txtBalance.Focus()
            txtBalance.Clear()
        Catch Exception As OverflowException
            MsgBox(strOverflow, , strMesssageBoxTitle)
            txtBalance.Focus()
            txtBalance.Clear()
        Catch Exception As SystemException
            MsgBox(strError, , strMesssageBoxTitle)
            txtBalance.Focus()
            txtBalance.Clear()
        End Try
        Return blnvalidityCheck
    End Function
    Private Sub radWithdraw_CheckedChanged(sender As Object, e As EventArgs) Handles radWithdraw.CheckedChanged
        'Displays stuff for withdrawals
        pnlTransactions.Visible = True
        txtCheck.Visible = True
        txtInput.Visible = False
        lblCheck.Visible = False
        lblHowTo.Visible = True
        pnlChoices.Visible = True
    End Sub
    Private Sub radDeposit_CheckedChanged(sender As Object, e As EventArgs) Handles radDeposit.CheckedChanged
        'Displays stuff for deposits.
        pnlTransactions.Visible = True
        txtCheck.Visible = True
        txtInput.Visible = False
        lblCheck.Visible = False
        lblHowTo.Visible = True
        pnlChoices.Visible = True
    End Sub
    Private Sub radCheck_CheckedChanged(sender As Object, e As EventArgs) Handles radCheck.CheckedChanged
        'Displays stuff for checks.
        pnlTransactions.Visible = True
        txtCheck.Visible = True
        txtInput.Visible = True
        lblCheck.Visible = True
        lblHowTo.Visible = True
        pnlChoices.Visible = True
    End Sub
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim intValidateAmount As Integer
        Dim blnValidateAmount As Boolean
        Dim blnValidateCheck As Boolean
        Dim intValidateCheck As Integer
        Dim decTransaction As Decimal
        Dim strTransaction As String
        Dim strCheckNumber As String
        Dim strError As String = "Please enter a valid amount."
        'Test
        Dim strError1 As String = "1."
        Dim strError2 As String = "2."
        Dim strError3 As String = "3."
        'Test
        Dim strMesssageBoxTitle As String = "Error"
        If radCheck.Checked = True Then
            'Does everthing if radio button Check is checked.
            Select Case intValidateAmount
                Case 0
                    blnValidateAmount = ValidateAmount(blnValidateAmount)
            End Select
            Select Case intValidateCheck
                Case 0
                    blnValidateCheck = ValidateCheck(blnValidateCheck)
            End Select
            If blnValidateAmount And blnValidateCheck = True Then
                decTransaction = Convert.ToDecimal(txtCheck.Text)
                Dim result As Integer = MessageBox.Show("Is the value entered correct? " & decTransaction.ToString("C"), "Continue?", MessageBoxButtons.YesNo)
                If result = DialogResult.No Then
                    txtBalance.Focus()
                    blnValidateAmount = False
                ElseIf result = DialogResult.Yes Then
                    strCheckNumber = txtInput.Text
                    decBalance = decBalance + Convert.ToDecimal(txtCheck.Text)
                    MsgBox("You deposited a " & decTransaction.ToString("C") & " check")
                    lstTransactions.Items.Add("Check Deposit " & "$" & decTransaction & " Check #" & strCheckNumber)
                    lblBalance.Text = "Your balance is " & decBalance.ToString("C")
                End If
            End If
        End If
        If radWithdraw.Checked = True Then
            Select Case intValidateAmount
                Case 0
                    blnValidateAmount = ValidateAmount(blnValidateAmount)
            End Select

            'Displays amount withdrawed and validates transaction amount.
            If blnValidateAmount = True AndAlso decTransaction <= decBalance Then
                decTransaction = Convert.ToDecimal(txtCheck.Text)
                If blnValidateAmount = True Then
                    Dim result As Integer = MessageBox.Show("Is the value entered correct? " & decTransaction.ToString("C"), "Continue?", MessageBoxButtons.YesNo)
                    If result = DialogResult.No Then
                        txtBalance.Focus()
                        blnValidateAmount = False
                    ElseIf result = DialogResult.Yes Then
                        Try ' Check transaction amount
                            decTransaction = Convert.ToDecimal(txtCheck.Text)
                            strTransaction = Convert.ToString(txtCheck.Text)
                            If decTransaction <= 0 And decTransaction > decBalance Then
                                MsgBox(strError, , strMesssageBoxTitle)
                                txtCheck.Focus()
                                txtCheck.Clear()
                            End If
                        Catch Exception As FormatException
                            MsgBox(strError, , strMesssageBoxTitle)
                            txtCheck.Focus()
                            txtCheck.Clear()
                        Catch Exception As OverflowException
                            MsgBox(strError, , strMesssageBoxTitle)
                            txtCheck.Focus()
                            txtCheck.Clear()
                        Catch Exception As SystemException
                            MsgBox(strError, , strMesssageBoxTitle)
                            txtCheck.Focus()
                            txtCheck.Clear()
                        End Try
                        decBalance = decBalance - Convert.ToDecimal(decTransaction)
                        MsgBox("You withdrawed " & decTransaction.ToString("C"))
                        lstTransactions.Items.Add("Withdrawed " & "$" & decTransaction)
                        lblBalance.Text = "Your balance is " & decBalance.ToString("C")
                    End If
                End If

            End If
        End If
        If radDeposit.Checked = True Then 'Does validation and then adds deposit to balance.

            Select Case intValidateAmount
                Case 0
                    blnValidateAmount = ValidateAmount(blnValidateAmount)
            End Select
            If blnValidateAmount = True Then
                decTransaction = Convert.ToDecimal(txtCheck.Text)
                Dim result As Integer = MessageBox.Show("Is the value entered correct? " & decTransaction.ToString("C"), "Continue?", MessageBoxButtons.YesNo)
                If result = DialogResult.No Then
                    txtBalance.Focus()
                    blnValidateAmount = False
                ElseIf result = DialogResult.Yes Then
                    decBalance = decBalance + Convert.ToDecimal(txtCheck.Text)
                    MsgBox("You deposited " & decTransaction.ToString("C"))
                    lblBalance.Text = "Your balance is " & decBalance.ToString("C")
                    lstTransactions.Items.Add("Deposited " & "$" & decTransaction)
                End If
            End If
        End If
    End Sub
    Private Function ValidateCheck(blnValidateCheck As Boolean) As Boolean
        ' This procedure validates the transaction value entered.
        Dim decCheckNumber As Decimal
        Dim strNotValid As String = "Please enter a positive value."
        Dim strError As String = "Please enter a valid check number."
        Dim strMesssageBoxTitle As String = "Error"
        Try
            decCheckNumber = Convert.ToDecimal(txtInput.Text)
            If decCheckNumber >= 0 Then
                blnValidateCheck = True
            ElseIf decCheckNumber <= 0 Then
                MsgBox(strNotValid, , strMesssageBoxTitle)
                txtCheck.Focus()
                txtInput.Clear()
                txtCheck.Clear()
            Else
                MsgBox(strNotValid, , strMesssageBoxTitle)
                txtCheck.Focus()
                txtInput.Clear()
                txtCheck.Clear()
            End If
        Catch Exception As FormatException
            MsgBox(strError, , strMesssageBoxTitle)
            txtCheck.Focus()
            txtInput.Clear()
            txtCheck.Clear()
        Catch Exception As OverflowException
            MsgBox(strError, , strMesssageBoxTitle)
            txtCheck.Focus()
            txtInput.Clear()
            txtCheck.Clear()
        Catch Exception As SystemException
            MsgBox(strError, , strMesssageBoxTitle)
            txtInput.Clear()
            txtCheck.Focus()
            txtCheck.Clear()
        End Try
        Return blnValidateCheck
    End Function
    Private Function ValidateAmount(blnValidateAmount As Boolean) As Boolean

        ' This procedure validates the transaction value entered.
        Dim decAmount As Decimal
        Dim strBalance As String = "Please enter a positive value."
        Dim strError As String = "Please enter a valid amount."
        Dim strMesssageBoxTitle As String = "Error"
        If radCheck.Checked Or radDeposit.Checked Then
            Try
                decAmount = Convert.ToDecimal(txtCheck.Text)
                If decAmount >= 0 Then
                    blnValidateAmount = True
                ElseIf decAmount <= 0 Then
                    MsgBox(strBalance, , strMesssageBoxTitle)
                    txtCheck.Focus()
                    txtInput.Clear()
                    txtCheck.Clear()
                Else
                    MsgBox(strBalance, , strMesssageBoxTitle)
                    txtCheck.Focus()
                    txtInput.Clear()
                    txtCheck.Clear()
                End If
            Catch Exception As FormatException
                MsgBox(strError, , strMesssageBoxTitle)
                txtCheck.Focus()
                txtInput.Clear()
                txtCheck.Clear()
            Catch Exception As OverflowException
                MsgBox(strError, , strMesssageBoxTitle)
                txtCheck.Focus()
                txtInput.Clear()
                txtCheck.Clear()
            Catch Exception As SystemException
                MsgBox(strError, , strMesssageBoxTitle)
                txtInput.Clear()
                txtCheck.Focus()
                txtCheck.Clear()
            End Try
        End If
        If radWithdraw.Checked Then
            Try
                decAmount = Convert.ToDecimal(txtCheck.Text)
                If decAmount >= 0 And decAmount <= decBalance Then
                    blnValidateAmount = True
                ElseIf decAmount <= 0 Then
                    MsgBox(strBalance, , strMesssageBoxTitle)
                    txtCheck.Focus()
                    txtInput.Clear()
                    txtCheck.Clear()
                Else
                    MsgBox(strBalance, , strMesssageBoxTitle)
                    txtCheck.Focus()
                    txtInput.Clear()
                    txtCheck.Clear()
                End If
            Catch Exception As FormatException
                MsgBox(strError, , strMesssageBoxTitle)
                txtCheck.Focus()
                txtInput.Clear()
                txtCheck.Clear()
            Catch Exception As OverflowException
                MsgBox(strError, , strMesssageBoxTitle)
                txtCheck.Focus()
                txtInput.Clear()
                txtCheck.Clear()
            Catch Exception As SystemException
                MsgBox(strError, , strMesssageBoxTitle)
                txtInput.Clear()
                txtCheck.Focus()
                txtCheck.Clear()
            End Try
        End If
        Return blnValidateAmount
    End Function
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Resets the whole form to be used again.
        lblBalance.Visible = False
        pnlChoices.Visible = False
        lblInstructions.Visible = False
        txtBalance.Text = ""
        chkInterest.Checked = False
        chkInterest.Enabled = True
        lblBalance.Text = ""
        lblInstructions.Text = ""
        pnlTransactions.Visible = False
        btnFinish.Visible = False
        btnClear.Visible = False
        btnContinue.Enabled = True
    End Sub
    Private Sub btnFinish_Click(sender As Object, e As EventArgs) Handles btnFinish.Click
        'Finalizes everything and allows user to close out of the application
        btnFinish.Enabled = False
        btnAdd.Enabled = False
        If chkInterest.Checked Then 'Adds interest amount for the month if user selected earlier
            decBalance = decBalance + (decBalance * _cdecInterest)
            MsgBox("Thank you for choosing the Online Bank. " & "Your final balance is " & decBalance.ToString("C"))
        Else
            MsgBox("Thank you for choosing The Online Bank. " & "Your final balance is " & decBalance.ToString("C"))
        End If
    End Sub
End Class