﻿' Name:    Factorial Math
' Date:    12/11/17
' Author:  Christopher I.
' Purpose: When the user clicks the calculate button, the application runs a loop
'          which does factorial math for the values 1-12 and displays it in a list box.
Option Strict On
Public Class frmFactorialMath
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clears the list box when the user clicks the Clear button.
        lstResults.Items.Clear()
        btnCalculate.Enabled = True
    End Sub
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'When the user clicks the calculate button, it runs a loop which does factorial math
        'and displays the results in a list box.
        Dim intFactorial As Integer = 1
        Dim intCounter As Integer = 1
        For intCounter = 1 To 12
            intFactorial = intCounter * (intFactorial)
            lstResults.Items.Add(intCounter & "!" & " " & intFactorial)
        Next
        btnCalculate.Enabled = False
    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Closes the application when the user clicks the Exit button.
        Me.Close()
    End Sub
End Class