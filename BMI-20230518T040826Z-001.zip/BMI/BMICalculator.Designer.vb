﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBMICalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBMICalculator))
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.picPic = New System.Windows.Forms.PictureBox()
        Me.txtHeight = New System.Windows.Forms.TextBox()
        Me.txtWeight = New System.Windows.Forms.TextBox()
        Me.lblWeight = New System.Windows.Forms.Label()
        Me.lblHeight = New System.Windows.Forms.Label()
        Me.lblInstruction = New System.Windows.Forms.Label()
        Me.cboMeasurement = New System.Windows.Forms.ComboBox()
        Me.lblResult = New System.Windows.Forms.Label()
        CType(Me.picPic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(170, 248)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 0
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        Me.btnCalculate.Visible = False
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Georgia", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(51, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(313, 25)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "Body Mass Index Calculator"
        '
        'picPic
        '
        Me.picPic.Image = CType(resources.GetObject("picPic.Image"), System.Drawing.Image)
        Me.picPic.Location = New System.Drawing.Point(46, 313)
        Me.picPic.Name = "picPic"
        Me.picPic.Size = New System.Drawing.Size(322, 172)
        Me.picPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPic.TabIndex = 2
        Me.picPic.TabStop = False
        '
        'txtHeight
        '
        Me.txtHeight.Location = New System.Drawing.Point(157, 200)
        Me.txtHeight.Name = "txtHeight"
        Me.txtHeight.Size = New System.Drawing.Size(100, 20)
        Me.txtHeight.TabIndex = 3
        Me.txtHeight.Visible = False
        '
        'txtWeight
        '
        Me.txtWeight.Location = New System.Drawing.Point(157, 174)
        Me.txtWeight.Name = "txtWeight"
        Me.txtWeight.Size = New System.Drawing.Size(100, 20)
        Me.txtWeight.TabIndex = 4
        Me.txtWeight.Visible = False
        '
        'lblWeight
        '
        Me.lblWeight.AutoSize = True
        Me.lblWeight.Location = New System.Drawing.Point(98, 177)
        Me.lblWeight.Name = "lblWeight"
        Me.lblWeight.Size = New System.Drawing.Size(44, 13)
        Me.lblWeight.TabIndex = 5
        Me.lblWeight.Text = "Weight:"
        Me.lblWeight.Visible = False
        '
        'lblHeight
        '
        Me.lblHeight.AutoSize = True
        Me.lblHeight.Location = New System.Drawing.Point(101, 203)
        Me.lblHeight.Name = "lblHeight"
        Me.lblHeight.Size = New System.Drawing.Size(41, 13)
        Me.lblHeight.TabIndex = 6
        Me.lblHeight.Text = "Height:"
        Me.lblHeight.Visible = False
        '
        'lblInstruction
        '
        Me.lblInstruction.AutoSize = True
        Me.lblInstruction.Location = New System.Drawing.Point(54, 49)
        Me.lblInstruction.Name = "lblInstruction"
        Me.lblInstruction.Size = New System.Drawing.Size(307, 52)
        Me.lblInstruction.TabIndex = 7
        Me.lblInstruction.Text = resources.GetString("lblInstruction.Text")
        Me.lblInstruction.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cboMeasurement
        '
        Me.cboMeasurement.FormattingEnabled = True
        Me.cboMeasurement.Items.AddRange(New Object() {"Imperial", "Metric"})
        Me.cboMeasurement.Location = New System.Drawing.Point(120, 129)
        Me.cboMeasurement.Name = "cboMeasurement"
        Me.cboMeasurement.Size = New System.Drawing.Size(174, 21)
        Me.cboMeasurement.TabIndex = 9
        Me.cboMeasurement.Text = "Choose system of measurement"
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Location = New System.Drawing.Point(157, 287)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(25, 13)
        Me.lblResult.TabIndex = 10
        Me.lblResult.Text = "filler"
        Me.lblResult.Visible = False
        '
        'frmBMICalculator
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(414, 486)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.cboMeasurement)
        Me.Controls.Add(Me.lblInstruction)
        Me.Controls.Add(Me.lblHeight)
        Me.Controls.Add(Me.lblWeight)
        Me.Controls.Add(Me.txtWeight)
        Me.Controls.Add(Me.txtHeight)
        Me.Controls.Add(Me.picPic)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.btnCalculate)
        Me.Name = "frmBMICalculator"
        Me.Text = "Body Mass Index Calculator"
        CType(Me.picPic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalculate As Button
    Friend WithEvents lblTitle As Label
    Friend WithEvents picPic As PictureBox
    Friend WithEvents txtHeight As TextBox
    Friend WithEvents txtWeight As TextBox
    Friend WithEvents lblWeight As Label
    Friend WithEvents lblHeight As Label
    Friend WithEvents lblInstruction As Label
    Friend WithEvents cboMeasurement As ComboBox
    Friend WithEvents lblResult As Label
End Class
