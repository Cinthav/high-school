﻿' Name: Body Mass Index Calculator
' Author: Christopher Inthavong
' Date: 2/14/18
' Purpose: This program takes values inputted to calculate a person's BMI.
Option Strict On
Public Class frmBMICalculator
    Private Sub frmBMICalculator_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Prepares the form for the user.
        Threading.Thread.Sleep(3000)
    End Sub
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Does all the calculations
        Dim decHeight As Decimal
        Dim decWeight As Decimal
        Dim intMeasurement As Integer
        Dim decTotal As Decimal
        Dim blnChoice As Boolean = False
        Dim blnMeasurements As Boolean = False
        intMeasurement = cboMeasurement.SelectedIndex
        Select Case intMeasurement
            Case 0
                decTotal = calcImperial(decWeight, decHeight, decTotal)
            Case 1
                decTotal = calcMetric(decWeight, decHeight, decTotal)
        End Select
        lblResult.Text = "Your BMI is " & decTotal.ToString("f2")
        lblResult.Visible = True
    End Sub
    Private Sub cboMeasurement_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboMeasurement.SelectedIndexChanged
        'Shows stuff
        btnCalculate.Visible = True
        txtHeight.Visible = True
        txtWeight.Visible = True
        lblHeight.Visible = True
        lblWeight.Visible = True
        lblHeight.Visible = True
        lblWeight.Visible = True
    End Sub
    Private Function calcImperial(decWeight As Decimal, decHeight As Decimal, decTotal As Decimal) As Decimal
        'Does math calculations if user selects Imperial System units.
        Dim strError As String = "Enter a valid amount for your weight and height."
        Try
            decHeight = Convert.ToDecimal(txtHeight.Text)
            decWeight = Convert.ToDecimal(txtWeight.Text)
        Catch Exception As FormatException
            MsgBox(strError)
            txtHeight.Text = ""
            txtWeight.Text = ""
        Catch Exception As OverflowException
            MsgBox(strError)
            txtHeight.Text = ""
            txtWeight.Text = ""
        Catch Exception As SystemException
            MsgBox(strError)
            txtHeight.Text = ""
            txtWeight.Text = ""
        End Try

        decTotal = (decWeight / (decHeight * decHeight)) * 703
        Return decTotal

    End Function
    Private Function calcMetric(decWeight As Decimal, decHeight As Decimal, decTotal As Decimal) As Decimal
        'Does math calculations if user selects Metric System units.
        Dim strError As String = "Enter a valid amount for your weight and height."
        Try
            decHeight = Convert.ToDecimal(txtHeight.Text)
            decWeight = Convert.ToDecimal(txtWeight.Text)
        Catch Exception As FormatException
            MsgBox(strError)
            txtHeight.Text = ""
            txtWeight.Text = ""
        Catch Exception As OverflowException
            MsgBox(strError)
            txtHeight.Text = ""
            txtWeight.Text = ""
        Catch Exception As SystemException
            MsgBox(strError)
            txtHeight.Text = ""
            txtWeight.Text = ""
        End Try
        decTotal = decWeight / (decHeight * decHeight)
        Return decTotal
    End Function
End Class