﻿' Name:    Smartphone Plans
' Date:    1/25/18
' Author:  Christopher Inthavong
' Purpose: The application allows the user to choose from two data plans by using 
'          a combo box. It also allows the user to enter their data usage and calculate
'          their bill.
Option Strict On
Public Class frmPlans
    Private Sub frmPlans_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Loads the splash screen and prepares the form.
        Threading.Thread.Sleep(4000)
        txtUsage.Focus()
        txtUsage.Clear()
    End Sub

    Private Sub btnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click
        'Maths
        Dim intGB As Integer
        Dim intPlan As Integer
        Dim blnGBEnteredIsValid As Boolean = False
        Dim decTotal As Decimal
        blnGBEnteredIsValid = ValidateNumber()
        If (blnGBEnteredIsValid) Then
            intGB = Convert.ToInt32(txtUsage.Text)
            intPlan = cboPlans.SelectedIndex
            Select Case intPlan
                Case 0
                    decTotal = BasicFindCost(intPlan, intGB, decTotal)
                Case 1
                    decTotal = DeluxeFindCost(intPlan, intGB, decTotal)
            End Select
            lblTotal.Text = decTotal.ToString("c") & " per month."
        End If
    End Sub
    Private Sub cboPlans_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboPlans.SelectedIndexChanged
        'Prepares the form after the user selects something from the combo box.
        btnClear.Visible = True
        btnCompute.Visible = True
        lblTotal.Visible = True
        lblUsage.Visible = True
        txtUsage.Visible = True
        txtUsage.Text = ""
        lblTotal.Text = ""
        txtUsage.Focus()
    End Sub
    Private Function BasicFindCost(ByVal intPlan As Integer, ByVal intGB As Integer, ByRef decTotal As Decimal) As Decimal
        'Does math for Basic Data Plan and returns a value
        Dim intPerMonth As Integer = 29
        Dim intCostPerGB As Integer = 4
        decTotal = intPerMonth + (intGB * intCostPerGB)
        Return decTotal
    End Function
    Private Function DeluxeFindCost(ByVal intPlan As Integer, ByVal intGB As Integer, ByRef decTotal As Decimal) As Decimal
        'Does math for Deluxe Data Plan and returns a value 
        Dim intPerMonth As Integer = 39
        Dim intCostPerGB As Integer = 1
        decTotal = intPerMonth + (intGB * intCostPerGB)
        Return decTotal
    End Function
    Private Function ValidateNumber() As Boolean
        ' This procedure validates the value entered.
        Dim intGB As Integer
        Dim blnValidityCheck As Boolean = False
        Dim strGB As String = "Please enter the amount of GB used."
        Dim strError As String = "Please enter a valid amount of GB used."
        Dim strMesssageBoxTitle As String = "Error"
        Try
            intGB = Convert.ToInt32(txtUsage.Text)
            If intGB >= 0 Then
                blnValidityCheck = True
            ElseIf intGB <= 0 Then
                MsgBox(strError, , strMesssageBoxTitle)
                txtUsage.Focus()
                txtUsage.Clear()
            Else
                MsgBox(strGB, , strMesssageBoxTitle)
                txtUsage.Focus()
                txtUsage.Clear()
            End If
        Catch Exception As FormatException
            MsgBox(strGB, , strMesssageBoxTitle)
            txtUsage.Focus()
            txtUsage.Clear()
        Catch Exception As OverflowException
            MsgBox(strGB, , strMesssageBoxTitle)
            txtUsage.Focus()
            txtUsage.Clear()
        Catch Exception As SystemException
            MsgBox(strGB, , strMesssageBoxTitle)
            txtUsage.Focus()
            txtUsage.Clear()
        End Try
        Return blnValidityCheck
    End Function
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Resets the form to default.
        cboPlans.Text = "Select a Data Plan."
        lblTotal.Text = ""
        txtUsage.Clear()
        txtUsage.Visible = False
        btnClear.Visible = False
        btnCompute.Visible = False
        lblTotal.Visible = False
        lblUsage.Visible = False

    End Sub
End Class