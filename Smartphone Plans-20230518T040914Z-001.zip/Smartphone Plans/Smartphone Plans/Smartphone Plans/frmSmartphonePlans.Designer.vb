﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPlans
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.txtUsage = New System.Windows.Forms.TextBox()
        Me.lblUsage = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCompute = New System.Windows.Forms.Button()
        Me.cboPlans = New System.Windows.Forms.ComboBox()
        Me.picPerson = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        CType(Me.picPerson, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Black
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(88, 19)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(326, 24)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "Select a Smartphone Plan Special"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.Controls.Add(Me.lblTotal)
        Me.Panel1.Controls.Add(Me.txtUsage)
        Me.Panel1.Controls.Add(Me.lblUsage)
        Me.Panel1.Controls.Add(Me.btnClear)
        Me.Panel1.Controls.Add(Me.btnCompute)
        Me.Panel1.Controls.Add(Me.cboPlans)
        Me.Panel1.Controls.Add(Me.lblTitle)
        Me.Panel1.Location = New System.Drawing.Point(201, -1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(503, 375)
        Me.Panel1.TabIndex = 2
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.BackColor = System.Drawing.Color.Black
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.ForeColor = System.Drawing.Color.White
        Me.lblTotal.Location = New System.Drawing.Point(199, 311)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(55, 15)
        Me.lblTotal.TabIndex = 7
        Me.lblTotal.Text = "xxxxxxxx"
        Me.lblTotal.Visible = False
        '
        'txtUsage
        '
        Me.txtUsage.Location = New System.Drawing.Point(337, 119)
        Me.txtUsage.Name = "txtUsage"
        Me.txtUsage.Size = New System.Drawing.Size(37, 20)
        Me.txtUsage.TabIndex = 6
        Me.txtUsage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtUsage.Visible = False
        '
        'lblUsage
        '
        Me.lblUsage.AutoSize = True
        Me.lblUsage.BackColor = System.Drawing.Color.LightGray
        Me.lblUsage.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUsage.Location = New System.Drawing.Point(129, 122)
        Me.lblUsage.Name = "lblUsage"
        Me.lblUsage.Size = New System.Drawing.Size(202, 13)
        Me.lblUsage.TabIndex = 5
        Me.lblUsage.Text = "Data Usage - Number of GB Used:"
        Me.lblUsage.Visible = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.Black
        Me.btnClear.ForeColor = System.Drawing.Color.White
        Me.btnClear.Location = New System.Drawing.Point(190, 237)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(123, 37)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Clear Form"
        Me.btnClear.UseVisualStyleBackColor = False
        Me.btnClear.Visible = False
        '
        'btnCompute
        '
        Me.btnCompute.BackColor = System.Drawing.Color.Black
        Me.btnCompute.ForeColor = System.Drawing.Color.White
        Me.btnCompute.Location = New System.Drawing.Point(190, 182)
        Me.btnCompute.Name = "btnCompute"
        Me.btnCompute.Size = New System.Drawing.Size(123, 37)
        Me.btnCompute.TabIndex = 3
        Me.btnCompute.Text = "Compute Total Bill"
        Me.btnCompute.UseVisualStyleBackColor = False
        Me.btnCompute.Visible = False
        '
        'cboPlans
        '
        Me.cboPlans.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboPlans.FormattingEnabled = True
        Me.cboPlans.Items.AddRange(New Object() {"Basic Plan: $29 a month plus $4 perGB of data", "Deluxe Plan: $39 a month plus $1 perGB of data"})
        Me.cboPlans.Location = New System.Drawing.Point(107, 63)
        Me.cboPlans.Name = "cboPlans"
        Me.cboPlans.Size = New System.Drawing.Size(289, 23)
        Me.cboPlans.TabIndex = 2
        Me.cboPlans.Text = "Select a Data Plan"
        '
        'picPerson
        '
        Me.picPerson.Image = Global.Smartphone_Plans.My.Resources.Resources.Smartphone
        Me.picPerson.Location = New System.Drawing.Point(-1, -1)
        Me.picPerson.Name = "picPerson"
        Me.picPerson.Size = New System.Drawing.Size(705, 375)
        Me.picPerson.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPerson.TabIndex = 0
        Me.picPerson.TabStop = False
        '
        'frmPlans
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(704, 375)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.picPerson)
        Me.Name = "frmPlans"
        Me.Text = "Smartphone Plan Specials"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.picPerson, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents picPerson As PictureBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents cboPlans As ComboBox
    Friend WithEvents txtUsage As TextBox
    Friend WithEvents lblUsage As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents btnCompute As Button
    Friend WithEvents lblTotal As Label
End Class
